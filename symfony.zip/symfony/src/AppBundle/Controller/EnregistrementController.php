<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Enregistrement;
use AppBundle\Entity\Achat;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

/**
 * Enregistrement controller.
 *
 * @Route("musique")
 */
class EnregistrementController extends Controller
{
    /**
     * Lists all enregistrement entities.
     *
     * @Route("/", name="musique_index")
     * @Method("GET")
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();
        $query = $em->createQuery(
          'SELECT e.codeMorceau ,e.titre, e.duree, e.prix
          FROM AppBundle:Enregistrement e'
          );

        $enregistrements = $query->getResult();

        return $this->render('enregistrement/index.html.twig', array(
            'enregistrements' => $enregistrements,
        ));
    }


    /**
     * Finds and displays a enregistrement entity.
     *
     * @Route("/{codeMorceau}", name="musique_show")
     * @Method("GET")
     */
    public function showAction(Enregistrement $enregistrement)
    {
        return $this->render('enregistrement/show.html.twig', array(
            'enregistrement' => $enregistrement,
        ));
    }
    /**
     * @Route("/addtocar/{codeMorceau}", name="addtocar")
     * @Method("GET")
     */
    public function addToCarAction(Enregistrement $enregistrement)
    {
      $abonne = $this->getUser();
      $codeAbonne = $abonne->getCodeAbonne();

      $em = $this->getDoctrine()->getManager();
      $achat = new Achat();
      $achat->setCodeAbonne($abonne);
      $achat->setCodeEnregistrement($enregistrement);

      $em->persist($achat);
      $em->flush();

      return $this->redirectToRoute('abonne_show',array(
          'codeAbonne' => $codeAbonne,
      ));
    }
    /**
    * @Route("/enregistrement/{codeMorceau}", name="musique_enregistrement")
    * @Method("GET")
    */
    public function photoAction($codeMorceau) {
      $inst = $this->getDoctrine()
      ->getRepository('AppBundle:Enregistrement')
      ->find($codeMorceau);
      $audio = stream_get_contents($inst->getExtrait());
      $response = new \Symfony\Component\HttpFoundation\Response();
      $response->headers->set('Content-type', 'audio/mpeg');
      $response->headers->set('Content-Transfer-Encoding', 'binary');
      $response->setContent($audio);
      return $response;
    }


}
