<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Abonne;
use AppBundle\Entity\Achat;
use AppBundle\Entity\Enregistrement;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;use Symfony\Component\HttpFoundation\Request;

/**
 * Abonne controller.
 *
 * @Route("abonne")
 */
class AbonneController extends Controller
{
    /**
     * Lists all abonne entities.
     *
     * @Route("/", name="abonne_index")
     * @Method("GET")
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();

        $abonnes = $em->getRepository('AppBundle:Abonne')->findAll();

        return $this->render('abonne/index.html.twig', array(
            'abonnes' => $abonnes,
        ));
    }

    /**
     * Creates a new abonne entity.
     *
     * @Route("/new", name="abonne_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {
        $abonne = new Abonne();
        $form = $this->createForm('AppBundle\Form\AbonneType', $abonne);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($abonne);
            $em->flush();

            return $this->redirectToRoute('abonne_show', array('codeAbonne' => $abonne->getCodeabonne()));
        }

        return $this->render('abonne/new.html.twig', array(
            'abonne' => $abonne,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a abonne entity.
     *
     * @Route("/{codeAbonne}", name="abonne_show")
     * @Method("GET")
     */
    public function showAction(Abonne $abonne)
    {
      /* redirige vers sa page utilisateur si tente d'acceder  */
       $usr= $this->getUser();

       if($usr != $abonne) {
         return $this->redirectToRoute('abonne_show', array('codeAbonne' => $usr->getCodeabonne()));
       }

        $deleteForm = $this->createDeleteForm($abonne);

        $em = $this->getDoctrine()->getManager();

    $query = $em->createQuery(
        'SELECT e
        FROM AppBundle:Enregistrement e
        JOIN AppBundle:Achat a WITH e.codeMorceau = a.codeEnregistrement
        WHERE a.codeAbonne = :code'
    )->setParameter('code', $abonne->getCodeabonne());

    // returns an array of Product objects
    $achats = $query->getResult();
    return $this->render('Security/user.html.twig', array(
      'abonne' => $abonne,
      'achats' => $achats,
      'delete_form' => $deleteForm->createView(),
    ));
    }
    /**
     * Finds and displays a abonne entity.
     *
     * @Route("/panier", name="abonne_panier")
     * @Method("GET")
     */
    public function panierAction()
    {
      /* redirige vers sa page utilisateur si tente d'acceder  */
       $abonne= $this->getUser();

        $em = $this->getDoctrine()->getManager();

    $query = $em->createQuery(
        'SELECT e.titre
        FROM AppBundle:Enregistrement e
        JOIN AppBundle:Achat a WITH e.codeMorceau = a.codeEnregistrement
        WHERE a.codeAbonne = :code'
    )->setParameter('code', $abonne->getCodeabonne());

    // returns an array of Product objects
    $achats = $query->getResult();
    return $achats;
    }

    /**
     * Displays a form to edit an existing abonne entity.
     *
     * @Route("/{codeAbonne}/edit", name="abonne_edit")
     * @Method({"GET", "POST"})
     */
    public function editAction(Request $request, Abonne $abonne)
    {
        $deleteForm = $this->createDeleteForm($abonne);
        $editForm = $this->createForm('AppBundle\Form\AbonneType', $abonne);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('abonne_edit', array('codeAbonne' => $abonne->getCodeabonne()));
        }

        return $this->render('abonne/edit.html.twig', array(
            'abonne' => $abonne,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a abonne entity.
     *
     * @Route("/{codeAbonne}", name="abonne_delete")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, Abonne $abonne)
    {
        $form = $this->createDeleteForm($abonne);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($abonne);
            $em->flush();
        }

        return $this->redirectToRoute('abonne_index');
    }

    /**
     * Creates a form to delete a abonne entity.
     *
     * @param Abonne $abonne The abonne entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Abonne $abonne)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('abonne_delete', array('codeAbonne' => $abonne->getCodeabonne())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}
