<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Musicien;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

/**
* Musicien controller.
*
* @Route("musicien")
*/
class MusicienController extends Controller
{
  /**
  * Lists all musicien entities.
  *
  * @Route("/", name="musicien_index")
  * @Method("GET")
  */
  public function indexAction()
  {
    $em = $this->getDoctrine()->getManager();

    $musiciens = $em->getRepository('AppBundle:Musicien')->findAll();

    return $this->render('musicien/index.html.twig', array(
      'musiciens' => $musiciens,
    ));
  }

  /**
  * Finds and displays a musicien entity.
  *
  * @Route("/{codeMusicien}", name="musicien_show")
  * @Method("GET")
  */
  public function showAction(Musicien $musicien)
  {

    return $this->render('musicien/show.html.twig', array(
      'musicien' => $musicien,
    ));
  }
  /**
  * @Route("/image/{codeMusicien}", name="musicien_photo")
  * @Method("GET")
  */
  public function photoAction($codeMusicien) {
    $inst = $this->getDoctrine()
    ->getRepository('AppBundle:Musicien')
    ->find($codeMusicien);
    $image = stream_get_contents($inst->getPhoto());
    $response = new \Symfony\Component\HttpFoundation\Response();
    $response->headers->set('Content-type', 'image/jpeg');
    $response->headers->set('Content-Transfer-Encoding', 'binary');
    $response->setContent($image);
    return $response;
  }
}
