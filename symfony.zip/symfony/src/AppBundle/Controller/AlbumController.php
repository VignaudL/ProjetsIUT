<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Album;
// use AppBundle\Entity\Disque;
use AppBundle\Entity\Enregistrement;
use AppBundle\Entity\CompositionDisque;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;


/**
 * Album controller.
 *
 * @Route("album")
 */
class AlbumController extends Controller
{
    /**
     * Lists all album entities.
     *
     * @Route("/", name="album_index")
     * @Method("GET")
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();

        $albums = $em->getRepository('AppBundle:Album')->findAll();

        return $this->render('album/index.html.twig', array(
            'albums' => $albums,
        ));
    }

    /**
     * Finds and displays a album entity.
     *
     * @Route("/{codeAlbum}", name="album_show")
     * @Method("GET")
     */
    public function showAction(Album $album)
    {
      $codeAlbum = $album->getCodeAlbum();
      $em = $this->getDoctrine()->getManager();

      $query = $em->createQuery(
      'SELECT d.codeDisque,d.referenceDisque
      FROM AppBundle:Disque d
      JOIN AppBundle:Album a WITH d.codeAlbum = a.codeAlbum
      WHERE d.codeAlbum = :code'
      )->setParameter('code', $album->getCodeAlbum());

      // returns an array of Product objects
      $disques = $query->getResult();

      foreach ($disques as &$disque) {
        if($disque['referenceDisque'] == "          ") {
          $disque['referenceDisque'] = "Disk 1";
        }
        $querydisque = $em->createQuery(
        'SELECT e.titre,e.duree,e.codeMorceau
        FROM AppBundle:Enregistrement e
        JOIN AppBundle:CompositionDisque c WITH e.codeMorceau = c.codeMorceau
        JOIN AppBundle:Disque d WITH c.codeDisque = d.codeDisque
        WHERE d.codeDisque = :code'
        )->setParameter('code', $disque['codeDisque']);

        $disque['enregistrements'] = $querydisque->getResult();

      }
        return $this->render('album/show.html.twig', array(
            'album' => $album,
            'disques' => $disques,
        ));
    }
    /**
* @Route("/pochette/{codeAlbum}", name="pochette")
     * @Method("GET")
*/
public function photoAction($codeAlbum) {
  $inst = $this->getDoctrine()
              ->getRepository('AppBundle:Album')
              ->find($codeAlbum);
      $image = stream_get_contents($inst->getPochette());
      $response = new \Symfony\Component\HttpFoundation\Response();
      $response->headers->set('Content-type', 'image/jpeg');
      $response->headers->set('Content-Transfer-Encoding', 'binary');
      $response->setContent($image);
      return $response;
}
}
