#ifndef GRID_H
#define GRID_H
#include "Cell.h"
#include <array>
#include <string>
#include <fstream>
#include <iostream>
const int ROW=5;
const int COL=7;


class Grid
{
    public:
    Grid();
    ~Grid();
    void initGrid(std::string file, int n);
    void drawGrid(sf::RenderWindow &window);
void initTestGrid();

    void initEditorTestGrid();
    Cell* getCell(int i, int j);

    Robot * m_bot;
    private:

    void initCellNeighbors();
    std::array<std::array<Cell*,COL>,ROW> m_grid;



};

#endif // GRID_H
