#ifndef EDITOR_H
#define EDITOR_H
#include "Manager.h"
#include "Appli.h"
#include "EditorGrid.h"
class Button;
//const float CELLRAD=50,
//CELLX=200.,
//CELLY=100., CELLW=CELLRAD*4., CELLH= (sqrt(3.))*CELLRAD;
const float HEXBUTY=539,HEXBUTW=128;
const float ADDX=265,ADDH=78;
const float DELETEX=393,DELETEH=72;
const float STARTX=521,STARTH=82;
const float  TREASUREX=649;


class Editor : public Manager
{
public:
    Editor(Appli* a);
    void loop()override;
    void mouse_pressed()override;
    void mouse_released()override;
    void mouse_moved()override;

    void drawEditor(sf::RenderWindow &window);
    ~Editor()override;
private:
    Appli * m_app;
    std::vector<Button *>m_buttonseditor;
    bool m_movingTool=false;
    EditorGrid * m_editorHexGrid;
    Button * m_movedTool=nullptr;


};

#endif // EDITOR_H
