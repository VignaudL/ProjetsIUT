#ifndef GAME_H
#define GAME_H
#include "Manager.h"
#include "Appli.h"
#include "Robot.h"


class Button;




class Game:public Manager
{
public:
    Game(Appli * a);
    void loop()override;
    void mouse_pressed()override;
    void mouse_released()override;
    void mouse_moved()override;
    void startLvl(int n);


    void draw_game(sf::RenderWindow &window,Coord pos);


    ~Game()override;
private:
    Appli * m_app;
    bool m_movingbutton;
    Button* m_movedbutton=nullptr;
    std::vector<Button*>m_buttonsgames;
    std::vector<Button*>m_actionsmain;
    std::vector<Button*>m_actionsp1;
    std::vector<Button*>m_actionsp2;
    bool m_isReadingActions=false;
    bool m_isReadingActionsP1=false;
    bool m_isReadingActionsP2=false;
    int m_indexMain=0;
    int m_indexP1=0;
    int m_indexP2=0;
    int m_currentLvl;

    bool isInMainFrame(Coord pos);
    bool isInP1Frame(Coord pos);
    bool isInP2Frame(Coord pos);
    void drawFrames(sf::RenderWindow &window,Coord pos);
    void readActions();



};

#endif // GAME_H
