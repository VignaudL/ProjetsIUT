#include "Cell.h"
/****************** Nom de la fonction **********************
* Cell*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Constructeur Cell*
*********************** Entrées *****************************
*2 entier i et  j correspondant aux indices d'une matrice*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Cell::Cell(int i, int j):m_i(i),m_j(j),m_startPos({CELLX,CELLY})
{  
    m_cellTexture.loadFromFile(HEXES);
    m_cellSprite.setTexture(m_cellTexture);
    m_neighbors["N"]=nullptr;
    m_neighbors["NE"]=nullptr;
    m_neighbors["SE"]=nullptr;
    m_neighbors["S"]=nullptr;
    m_neighbors["SW"]=nullptr;
    m_neighbors["NW"]=nullptr;





}
/****************** Nom de la fonction **********************
* draw_hex*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de dessiner une cellule*
*********************** Entrées *****************************
*une fenêtre de rendu*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Cell::draw_Hex(sf::RenderWindow &window)
{

    setHexAppearance();


    window.draw(m_cellSprite);
}
/****************** Nom de la fonction **********************
* initCell*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet d'intialiser une cellule*
*********************** Entrées *****************************
*3 entier n  , i et  j *
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Cell::initCell(int n, int i, int j)
{
    m_altitude=i2HexHeight(n);
    m_type=i2HexType(n);
    m_cellSprite.setPosition(int2Pos(i,j));
}
/****************** Nom de la fonction **********************
* setHexAppearance*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de défnir l'apparence graphique d'une cellule*
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Cell::setHexAppearance()
{


    switch(m_type)
    {
    case HexType::DEFAULT:
        m_cellSprite.setTextureRect(sf::IntRect(256,50,128,78));
        m_cellSprite.setPosition(int2Pos(m_i,m_j));
        break;
    case HexType::START:

        m_cellSprite.setTextureRect(sf::IntRect(512,46,128,82));
        m_cellSprite.setPosition(int2Pos(m_i,m_j));

        break;
    case HexType::TREASUREOFF:
        m_cellSprite.setTextureRect(sf::IntRect(896,50,128,78));
        m_cellSprite.setPosition(int2Pos(m_i,m_j));
        break;
    case HexType::TREASUREON:
        m_cellSprite.setTextureRect(sf::IntRect(0,178,128,78));
        m_cellSprite.setPosition(int2Pos(m_i,m_j));
        break;
    }
    sf::IntRect rect=m_cellSprite.getTextureRect();
    rect.left+=128;
    rect.top-=44;

    switch(m_altitude)
    {
    case HexHeight::DEFAULT:
        m_cellCenter={m_cellSprite.getPosition().x+64,m_cellSprite.getPosition().y+32};
        m_cellSprite.setPosition(int2Pos(m_i,m_j));

        break;
    case HexHeight::HOLE:
        m_cellSprite.setTextureRect(sf::IntRect(1029,262,128,78));
        m_cellCenter={0.,0.};

        break;
    case HexHeight::FIRSTFLOOR:
        m_cellSprite.setTextureRect(sf::IntRect( rect.left,rect.top,122,128));
        m_cellCenter={m_cellSprite.getPosition().x+64,m_cellSprite.getPosition().y+35};
        break;
    case HexHeight::SECONDFLOOR:
        m_cellSprite.setTextureRect(sf::IntRect( rect.left,rect.top,122,128));
        m_cellCenter={m_cellSprite.getPosition().x+64,m_cellSprite.getPosition().y+35};
        break;
    }




}
/****************** Nom de la fonction **********************
* int2pos*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
* Convertit  2 entiers en une position*
*********************** Entrées *****************************
*2 entiers*
*********************** Sorties *****************************
*une position*
************************************************************/
Coord  Cell::int2Pos(int i, int j)
{
    if(j%2==0 )
    {
        if(m_altitude==HexHeight::FIRSTFLOOR)
        {
            return {m_startPos.x+(j*OFFSETDX),m_startPos.y+(i*OFFSETY)-22};
        }
        else if(m_altitude==HexHeight::SECONDFLOOR)
        {
            return {m_startPos.x+(j*OFFSETDX),m_startPos.y+(i*OFFSETY)-44};
        }
        return {m_startPos.x+(j*OFFSETDX),m_startPos.y+(i*OFFSETY)};
    }
    else
    {
        if(m_altitude==HexHeight::FIRSTFLOOR)
        {
            return {m_startPos.x+(j*OFFSETDX),m_startPos.y +36+(i*OFFSETY)-22};
        }
        else if(m_altitude==HexHeight::SECONDFLOOR)
        {
            return {m_startPos.x+(j*OFFSETDX),m_startPos.y +36+(i*OFFSETY)-44};
        }

        return {m_startPos.x+(j*OFFSETDX),m_startPos.y +36+(i*OFFSETY)};
    }
}
/****************** Nom de la fonction **********************
* i2HexHeight*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Converti un entier en une hauteur de cellule*
*********************** Entrées *****************************
*un entier*
*********************** Sorties *****************************
*une hauteur de cellule*
************************************************************/
HexHeight Cell::i2HexHeight(int i)
{
    int n = i/10;
    if(n==2)
    {
        return HexHeight::FIRSTFLOOR;
    }
    else if(n==3)
    {
        return HexHeight::SECONDFLOOR;
    }
    else if(n==4)
    {
        return HexHeight::HOLE;
    }
    else
    {
        return HexHeight::DEFAULT;
    }

}
/****************** Nom de la fonction **********************
* i2HexType*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Convertit un entier en un type de cellule*
*********************** Entrées *****************************
*un entier*
*********************** Sorties *****************************
*un type de cellule*
************************************************************/
HexType Cell::i2HexType(int i)
{
    int n = i%10;
    if( n==2)
    {
        return HexType::START;
    }
    else if( n==3)
    {
        return HexType::TREASUREOFF;
    }
    else if (n==4)
    {
        return HexType::TREASUREON;
    }
    else
    {
        return HexType::DEFAULT;
    }
}
/****************** Nom de la fonction **********************
* addNeighbor*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet d'ajouter un voisin à une cellule dans la direction souhaitée*
*********************** Entrées *****************************
*Un pointeur de cellule et une direction*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Cell::addNeighbor(std::string dir, Cell *c)
{
    m_neighbors[dir]=c;
}
/****************** Nom de la fonction **********************
* getNeighbor*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de récupérer le voisin d'une cellule dans une direction donnée*
*********************** Entrées *****************************
*une direction*
*********************** Sorties *****************************
*Un pointeur de cellule*
************************************************************/
Cell* Cell::getNeighbor(std::string dir)
{
    if(m_neighbors[dir]!=nullptr)
    {
        return m_neighbors[dir];
    }
    else return this;
}
/****************** Nom de la fonction **********************
* getCenter*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  getter de la position du centre de la cellule*
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*une position*
************************************************************/
Coord Cell::getCenter()
{
    return m_cellCenter;
}
/****************** Nom de la fonction **********************
* getHeight*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*getter de la hauteur d'une cellule*
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Hauteur d'une cellule*
************************************************************/
HexHeight Cell::getHeight()
{
    return m_altitude;
}
/****************** Nom de la fonction **********************
* getType*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  getter du type d'une cellule
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Type d'une ecllule*
************************************************************/
HexType Cell::getType()
{
    return m_type;
}
/****************** Nom de la fonction **********************
* iscellValid*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Vérifie que la cellule sur laquelle se dirige la robot est valide par rapport à la position actuelle du robot*
*********************** Entrées *****************************
*Un pointeur de cellule et un booléen*
*********************** Sorties *****************************
*Un booléen*
************************************************************/
bool Cell::isCellValid(Cell *c,bool jump)
{
    if(((c->getHeight()==HexHeight::DEFAULT && m_altitude==HexHeight::FIRSTFLOOR)||(m_altitude==HexHeight::DEFAULT && c->getHeight()==HexHeight::FIRSTFLOOR))&& !jump)
    {
        return false;
    }
    else if(((c->getHeight()==HexHeight::FIRSTFLOOR && m_altitude==HexHeight::SECONDFLOOR)||(m_altitude==HexHeight::FIRSTFLOOR && c->getHeight()==HexHeight::SECONDFLOOR))&& !jump)
    {
        return false;
    }
    else if ((c->getHeight()==HexHeight::DEFAULT && m_altitude==HexHeight::SECONDFLOOR) ||(m_altitude==HexHeight::DEFAULT && c->getHeight()==HexHeight::SECONDFLOOR))
    {
        return false;
    }
    else if (m_altitude ==HexHeight::HOLE)
    {
        return false;
    }

    return true;
}
/****************** Nom de la fonction **********************
* setType*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  setter du type de cellule*
*********************** Entrées *****************************
*Un type de cellule*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Cell::setType(HexType t)
{
    m_type =t;
}
void Cell::setHeight(HexHeight h)
{
    m_altitude=h;
}
/****************** Nom de la fonction **********************
* repositionGrid*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
* permet de redéfinir la position de départ des celluls
*********************** Entrées *****************************
*Une position*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Cell::repositionStartPos(Coord pos)
{
    m_startPos=pos;
}
