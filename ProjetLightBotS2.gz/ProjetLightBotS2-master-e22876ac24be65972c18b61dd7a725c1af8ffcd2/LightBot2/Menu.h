class Appli;
#ifndef MENU_H
#define MENU_H

#include "Appli.h"
#include <SFML/Graphics.hpp>
#include <vector>
#include "Button.h"

const float PLAYW=132,
PLAYH=88,
PLAYX=569,
PLAYY=317,
QUITW=90,
QUITH=90,
QUITX=509,
QUITY=317+88+4,
MENUEDITW=QUITW,
MENUEDITH=QUITH,
MENUEDITX=502+276-MENUEDITW,
MENUEDITY=QUITY,
LEVELXY=50,
LEVELWH=200,
LEVELSPACING=70;

class Menu
{
public:
    Menu(Appli *a);
    ~Menu();
    void loop();
    void mouse_pressed();
private :
    Appli *m_app;
    bool m_main=true;
    std::vector<Button *> m_mainButtons;
    std::vector<Button*> m_lvlSelectButtons;
    void menuAction(Button *b);
    void lvlSelectAction(Button *b);
    sf::Sprite m_background;
    sf::Texture m_bgTex;




    void changeMenuState();
};

#endif // MENU_H
