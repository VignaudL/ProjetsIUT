#include "Game.h"

/****************** Nom de la fonction **********************
*Game*
******************** Auteur , Dates *************************
*Montferme Robin, Loic Vignaud*
********************* Description ***************************
*Constructeur de game*
*********************** Entrées *****************************
*Pointeur d'application*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Game::Game(Appli * a):m_app(a)
{
    m_BGText.loadFromFile(GAMEBG);
    m_backGround.setTexture(m_BGText);
    m_movingbutton = false;

    m_hexgrid = new Grid();
    m_hexgrid->initTestGrid();



    m_buttonsgames.push_back(new Button({0.,0.},ButtonType::Quit,45));
    m_buttonsgames.push_back(new Button({GPLAYX,GPLAYY},ButtonType::Play,GPLAYW,GPLAYH));
    m_buttonsgames.push_back(new Button({GCLEARX,GCLEARY},ButtonType::Clear,GCLEARW,GCLEARH));
    m_buttonsgames.push_back(new Button({170.,575.},ButtonType::JeuAvancer, GBUTTONW, GBUTTONH));
    m_buttonsgames.push_back(new Button({245.,575.},ButtonType::JeuPivotG, GBUTTONW, GBUTTONH));
    m_buttonsgames.push_back(new Button({320.,575.},ButtonType::JeuPivotD, GBUTTONW, GBUTTONH));
    m_buttonsgames.push_back(new Button({395.,575.},ButtonType::JeuSauter, GBUTTONW, GBUTTONH));
    m_buttonsgames.push_back(new Button({470.,575.},ButtonType::JeuAllumer, GBUTTONW, GBUTTONH));
    m_buttonsgames.push_back(new Button({545.,575.},ButtonType::JeuP1, GBUTTONW, GBUTTONH));
    m_buttonsgames.push_back(new Button({620.,575.},ButtonType::JeuP2, GBUTTONW, GBUTTONH));
}
/****************** Nom de la fonction **********************
*loop*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*boucle  liés à l'affichage du jeu
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Game::loop()
{
    m_app->m_window.clear();
    readActions();

    draw_game(m_app->m_window,m_app->m_mouse);
    m_app->m_window.display();

}


/****************** Nom de la fonction **********************
*mouse_pressed*
******************** Auteur , Dates *************************
* Montferme Robin,Loic Vignaud*
********************* Description ***************************
*gère les événement lié au clique maintenu de la souris
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Game::mouse_pressed()
{
    for(Button * b:m_buttonsgames)
    {
        if(b->isOnButton(m_app->m_mouse))
        {
            switch(b->getType())
            {

            case ButtonType::Quit:
                m_app->changeState(State::menu);
                break;
            case ButtonType::Play:
                if(m_actionsmain.size()!=0)
                {
                    m_isReadingActions=true;
                    m_indexMain=0;
                    m_indexP1=0;
                    m_indexP2=0;    bool m_toolSelected;

                    ButtonType m_tool=ButtonType::null;

                    b->switchGameButton();
                }
                break;
            case ButtonType::JeuReset:
                m_isReadingActions=false;
                m_indexMain=0;
                m_indexP1=0;
                b->switchGameButton();
                m_hexgrid->initTestGrid();

                break;
            case ButtonType::Clear:
                if(!m_isReadingActions)
                {

                    //Debug Features
                    m_actionsmain.clear();
                    m_actionsp1.clear();
                    m_actionsp2.clear();
                }
                break;


            case ButtonType::JeuAvancer:
                // m_hexgrid->m_bot->moveForward();
                m_movingbutton = true;
                m_movedbutton = new Button(b);

                break;

            case ButtonType::JeuPivotG:
                // m_hexgrid->m_bot->rotation(Sens::ANTIHORAIRE);
                m_movingbutton = true;
                m_movedbutton = new Button(b);
                break;

            case ButtonType::JeuPivotD:
                //  m_hexgrid->m_bot->rotation(Sens::HORAIRE);
                m_movingbutton = true;
                m_movedbutton = new Button(b);
                break;

            case ButtonType::JeuSauter:
                // m_hexgrid->m_bot->jumpForward();
                m_movingbutton = true;
                m_movedbutton = new Button(b);
                break;

            case ButtonType::JeuAllumer:
                // m_hexgrid->m_bot->lightCell();
                m_movingbutton = true;
                m_movedbutton = new Button(b);
                break;

            case ButtonType::JeuP1:
                m_movingbutton = true;
                m_movedbutton = new Button(b);
                break;

            case ButtonType::JeuP2:
                m_movingbutton = true;
                m_movedbutton = new Button(b);
                break;

            default:
                break;
            }

        }

    }
    for(int i=0; (size_t)i<m_actionsmain.size();i++)
    {
        if(m_actionsmain[i]->isOnButton(m_app->m_mouse))
        {
            m_movedbutton = new Button(m_actionsmain[i]);
            m_movingbutton=true;
            m_actionsmain[i]=nullptr;

            m_actionsmain.erase(m_actionsmain.begin()+i);


        }
    }
    for(int i=0; (size_t)i<m_actionsp1.size();i++)
    {
        if(m_actionsp1[i]->isOnButton(m_app->m_mouse))
        {
            m_movedbutton = new Button(m_actionsp1[i]);
            m_movingbutton=true;
            m_actionsp1[i]=nullptr;

            m_actionsp1.erase(m_actionsp1.begin()+i);


        }
    }
    for(int i=0; (size_t)i<m_actionsp2.size();i++)
    {
        if(m_actionsp2[i]->isOnButton(m_app->m_mouse))
        {
            m_movedbutton = new Button(m_actionsp2[i]);
            m_movingbutton=true;
            m_actionsp2[i]=nullptr;

            m_actionsp2.erase(m_actionsp2.begin()+i);


        }
    }

}
/****************** Nom de la fonction **********************
* mouse_released*
******************** Auteur , Dates *************************
* Montferme Robin,Loic Vignaud*
********************* Description ***************************
*  gère les évènements liés au relachement du clique de souris*
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Game::mouse_released()
{
    if(m_movingbutton)
    {
        m_movingbutton = false;
        if(isInMainFrame(m_movedbutton->getButtonPos()) && m_actionsmain.size()<10)
        {
            m_actionsmain.push_back(new Button(m_movedbutton));
            delete m_movedbutton;
            m_movedbutton=nullptr;
        }

        else if (isInP1Frame(m_movedbutton->getButtonPos())&& m_actionsp1.size()<8)
        {
            m_actionsp1.push_back(new Button(m_movedbutton));
            delete m_movedbutton;
            m_movedbutton=nullptr;
        }
        else if (isInP2Frame(m_movedbutton->getButtonPos()) && m_actionsp2.size()<4)
        {
            m_actionsp2.push_back(new Button(m_movedbutton));
            delete m_movedbutton;
            m_movedbutton=nullptr;
        }


    }


}

/****************** Nom de la fonction **********************
* mouse_moved*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  gère les évènements liés au mouvement de la souris*
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Game::mouse_moved()
{
    if (m_movingbutton){

        m_movedbutton->setButtonPos(m_app->m_mouse);
    }
}

/****************** Nom de la fonction **********************
* draw_game*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*dessine le jeu et ses composant*
*********************** Entrées *****************************
*une fenêtre de rendu et une position*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Game::draw_game(sf::RenderWindow &window, Coord pos)
{
    window.draw(m_backGround);

    for(Button * b:m_buttonsgames)
    {
        b->draw_Button(window,pos);
    }

    m_hexgrid->drawGrid(window);
    if(m_movingbutton)
    {
        m_movedbutton->draw_Button(window,pos);
    }
    drawFrames(window,pos);
    m_hexgrid->m_bot->drawRobot(window);
}
/****************** Nom de la fonction **********************
* draw_frame*
******************** Auteur , Dates *************************
* Loic Vignaud,Montferme Robin*
********************* Description ***************************
*  Affiche les instruction des micros programme *
*********************** Entrées *****************************
*une fenêtre de rendu et une position*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Game::drawFrames(sf::RenderWindow &window, Coord pos)
{
    int i=0; int j=0;
    for(Button* a: m_actionsmain)
    {
        a->setButtonPos({(850 + i*GBUTTONW),(85 + j*GBUTTONH)});
        a->draw_Button(window, pos);
        i++;
        if (i>4){
            i=0;
            j=1;
        }
    }
    i=0;
    j=0;
    for(Button* b: m_actionsp1)
    {
        b->setButtonPos({(850 + i*GBUTTONW),(314 + j*GBUTTONH)});
        b->draw_Button(window, pos);

        i++;
        if (i>3){
            i=0;
            j=1;
        }
    }
    i=0;

    for(Button* c: m_actionsp2)
    {
        c->setButtonPos({(850 + i*GBUTTONW),543.});
        c->draw_Button(window, pos);
        i++;
    }
}

/****************** Nom de la fonction **********************
* ~Game*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*Destructeur de Game
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Game::~Game()
{
    for(auto b:m_buttonsgames)
    {
        delete b;
    }
    delete m_hexgrid;
    if(m_actionsmain.size()>0)
    {
        for(auto b:m_actionsmain)
        {
            delete b;
        }
    }
    if(m_actionsp1.size()>0)
    {
        m_hexgrid->m_bot->lightCell();
        for(auto b:m_actionsp1)
        {
            delete b;
        }
    }
    if(m_actionsp2.size()>0)
    {
        for(auto b:m_actionsp2)
        {
            delete b;
        }
    }
}
/****************** Nom de la fonction **********************
* isInMainFrame*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  vérifie si la position de  la souris est bien dans le cadre "Main" des micros programmes
*********************** Entrées *****************************
*Une position*
*********************** Sorties *****************************
*une booléen*
************************************************************/
bool Game::isInMainFrame(Coord pos)
{
    return (pos.x>850 && pos.x<1225 && pos.y >85 && pos.y<235);
}
/****************** Nom de la fonction **********************
*isInP1Frame*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
* vérifie si la souris est dans le cardre "P1" des micros programmes
*********************** Entrées *****************************
*une position*
*********************** Sorties *****************************
* un booléen*
************************************************************/
bool Game::isInP1Frame(Coord pos)
{
    return (pos.x>850&&pos.x<1150 &&pos.y>315 && pos.y<465);
}
/****************** Nom de la fonction **********************
*isInP2Frame*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
* vérifie si la souris est dans le cardre "P2" des micros programmes
*********************** Entrées *****************************
*une position*
*********************** Sorties *****************************
* un booléen*
************************************************************/
bool Game::isInP2Frame(Coord pos)
{
    return (pos.x>850 && pos.x<1150 && pos.y>543 && pos.y<618);
}
/****************** Nom de la fonction **********************
* readActions*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*Lit les instructions contenues dans les cadres main P1 et P2 et les applique au robot
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Game::readActions()
{
    ButtonType reader;
    if((size_t)m_indexMain==m_actionsmain.size() &&m_isReadingActions)
    {
        m_isReadingActions=false;
        m_isReadingActionsP1=false;
        m_isReadingActionsP2=false;
        m_indexMain=0;
        m_indexP1=0;
        m_indexP2=0;
    }
    //Lecture de P1
    if(m_isReadingActions&& m_isReadingActionsP1&&!m_isReadingActionsP2)
    {
        reader=m_actionsp1[m_indexP1]->getType();
        switch(reader)
        {
        case ButtonType::JeuAvancer:
            m_hexgrid->m_bot->moveForward();
            break;
        case ButtonType::JeuPivotG:
            m_hexgrid->m_bot->rotation(Sens::ANTIHORAIRE);
            break;
        case ButtonType::JeuPivotD:
            m_hexgrid->m_bot->rotation(Sens::HORAIRE);
            break;
        case ButtonType::JeuSauter:
            m_hexgrid->m_bot->jumpForward();
            break;
        case ButtonType::JeuAllumer:
            m_hexgrid->m_bot->lightCell();
            break;
        case ButtonType::JeuP1:
            m_indexP1=-1;
            break;
        case ButtonType::JeuP2:
            m_isReadingActionsP1=false;
            m_isReadingActionsP2=true;
            break;
        default:
            break;
        }
        if((size_t) m_indexP1==m_actionsp1.size()-1/*&& m_actionsp1.size()!=0*/)
        {
            m_isReadingActionsP1=false;

            m_indexP1=0;
            if(!m_isReadingActionsP2)
            {
                m_indexMain++;
            }
        }

        //Debug Features
        else
        {
            m_indexP1++;
        }
    }
    //Lecture de P2
    if(m_isReadingActions&& m_isReadingActionsP2&&!m_isReadingActionsP1)
    {
        reader=m_actionsp2[m_indexP2]->getType();
        switch(reader)
        {
        case ButtonType::JeuAvancer:
            m_hexgrid->m_bot->moveForward();
            break;
        case ButtonType::JeuPivotG:
            m_hexgrid->m_bot->rotation(Sens::ANTIHORAIRE);
            break;
        case ButtonType::JeuPivotD:
            m_hexgrid->m_bot->rotation(Sens::HORAIRE);
            break;
        case ButtonType::JeuSauter:
            m_hexgrid->m_bot->jumpForward();
            break;
        case ButtonType::JeuAllumer:
            m_hexgrid->m_bot->lightCell();
            break;
        case ButtonType::JeuP1:
            m_isReadingActionsP2=false;
            m_isReadingActionsP1=true;
            break;
        case ButtonType::JeuP2:
            m_indexP2=-1;
            break;
        default:
            break;
        }
        if( (size_t)m_indexP2==m_actionsp2.size()-1/* && m_actionsp2.size()!=0*/)
        {
            m_isReadingActionsP2=false;

            m_indexP2=0;
            if(!m_isReadingActionsP1)
            {
                m_indexMain++;
            }
        }
        else{
            m_indexP2++;
        }
    }
    //Lecture de main
    if(m_isReadingActions&&!m_isReadingActionsP1&&!m_isReadingActionsP2)
    {
        reader=m_actionsmain[m_indexMain]->getType();
        switch(reader)
        {
        case ButtonType::JeuAvancer:
            m_hexgrid->m_bot->moveForward();
            m_indexMain++;
            break;
        case ButtonType::JeuPivotG:
            m_hexgrid->m_bot->rotation(Sens::ANTIHORAIRE);
            m_indexMain++;
            break;
        case ButtonType::JeuPivotD:
            m_hexgrid->m_bot->rotation(Sens::HORAIRE);
            m_indexMain++;
            break;
        case ButtonType::JeuSauter:
            m_hexgrid->m_bot->jumpForward();
            m_indexMain++;
            break;
        case ButtonType::JeuAllumer:
            m_hexgrid->m_bot->lightCell();
            m_indexMain++;
            break;
        case ButtonType::JeuP1:
            if(m_actionsp1.size()!=0)
            {
                m_isReadingActionsP1=true;
            }
            break;
        case ButtonType::JeuP2:
            if(m_actionsp2.size()!=0)
            {
                m_isReadingActionsP2=true;
            }
            break;
        default:
            break;
        }
    }
}

void Game::startLvl(int n)
{
  m_currentLvl=n;

}
