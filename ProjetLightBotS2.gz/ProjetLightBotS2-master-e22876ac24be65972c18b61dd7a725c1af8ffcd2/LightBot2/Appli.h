#ifndef APPLI_H
#define APPLI_H

#include"Menu.h"
#include "Game.h"
#include "Editor.h"
#include <map>


const std::string BACK ="../Ressources/Background.png",
        GAMEBG="../Ressources/BackgroundGame.png";

#include<SFML/Graphics.hpp>
class Menu;
class Game;
class Editor;


const unsigned int W=1280;
const unsigned int H=720;
enum class State{menu,game,editor};


using Coord = sf::Vector2f;

class Appli
{
public:
    Appli();
    ~Appli();
    void run();
    void setMousePos(float x, float y );
    void changeState(State s);
    void launchLvl(int n);
    void stop();

    Coord m_mouse;
    sf::RenderWindow m_window;



private:
    bool m_running=false;
    State m_state;
    Menu * m_menu;    
    Game*m_game;
    Editor * m_editor;




    void process_event();





};

#endif // APPLI_H
