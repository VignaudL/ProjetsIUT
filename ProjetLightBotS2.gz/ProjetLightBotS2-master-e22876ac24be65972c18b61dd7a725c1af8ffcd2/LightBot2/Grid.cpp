#include "Grid.h"

/****************** Nom de la fonction **********************
* Grid*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  constructeur de grid
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Grid::Grid()
{

}
/****************** Nom de la fonction **********************
* ~Grid*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Destructeur de Grid
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Grid::~Grid()
{
    for (int i =0;i<ROW;i++)
    {
        for(int j=0;j<COL;j++)
        {
            delete m_grid[i][j];
        }
    }
    delete m_bot;
}
/****************** Nom de la fonction **********************
* drawGrid*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  permet d'afficher la grille
*********************** Entrées *****************************
*Uen fenêtre de rendu*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Grid::drawGrid(sf::RenderWindow &window)
{
    for(int i = 0; i<ROW;i++)
    {
        for(int j = 0 ; j<COL;j+=2)
        {
            m_grid[i][j]->draw_Hex(window);
        }
        for(int j = 1; j<COL;j+=2)
        {
            m_grid[i][j]->draw_Hex(window);
        }
    }
}
/****************** Nom de la fonction **********************
*InitGrid*
******************** Auteur , Dates *************************
* Loic Vignaud*
********************* Description ***************************
*  Initialise la grille et le niveau à partir d'un fichier
*********************** Entrées *****************************
*une chaine de caractère et un caractère*
******************for(int i =0 ; i<ROW;i++)
    {
        for (int j =0; j<COL;j++)
        {
            m_grid[i][j]=new Cell(i,j);
            m_grid[i][j]->repositionStartPos({25.,25.});
            m_grid[i][j]->initCell(10,i,j);***** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Grid::initGrid(std::string file, int n)
{
    std::fstream f;
    std::string s="";
    int id;
    int dir;
//    file+std::to_string(n+1);
    file.append(std::to_string(n+1));
    f.open( file.c_str(), std::ios::in );
    if( f.fail() )
    {
        std::cerr << "ouverture en lecture impossible" << std::endl;
        exit(EXIT_FAILURE);
    }
    f>>dir;

    for( int i=0; i<COL; i++ )
    {
        for( int j=0; j<ROW; j++ )
        {
            f>>id;
            m_grid[i][j]=new Cell(i,j);
            m_grid[i][j]->initCell(id,i,j);    // On rentre chaque entier lu dans le fichier afin de le mettre dans l'id de la Cell présente dans la case.
        }
    }
    f.close();
    initCellNeighbors();
    int i =0, j=0;
    Direction d;
    bool foundStart = false;
    switch(dir)
    {
    case 0:
        d=Direction::N;
        break;
    case 1:
        d=Direction::NE;
        break;
    case 3:
        d=Direction::S;
        break;
    case 4:
        d=Direction::SW;
        break;
    case 5:
        d=Direction::NW;
        break;
    default:
        d=Direction::SE;
        break;

    }
    while(i<ROW && !foundStart)
    {
        j=0;
        while(j<COL && !foundStart)
        {
            if(m_grid[i][j]->getType()==HexType::START)
            {
                m_bot =new Robot(m_grid[i][j],d);
                foundStart=true;
            }
            j++;
        }
        i++;
    }
}
//FONCTION DE TEST A RETIRER
void Grid::initTestGrid()
{
    for(int i =0 ; i<ROW;i++)
    {
        for (int j =0; j<COL;j++)
        {
            m_grid[i][j]=new Cell(i,j);
            m_grid[i][j]->initCell(10,i,j);
            if(i==2&&j==2)
            {
                m_grid[i][j]->initCell(23,i,j);
            }
            if(i==3&&j==2)
            {
                m_grid[i][j]->initCell(12,i,j);
            }
            if(i==3&&j==6)
            {
                m_grid[i][j]->initCell(30,i,j);
            }
            if(i==4&&j==6)
            {
                m_grid[i][j]->initCell(20,i,j);
            }

        }
    }

    initCellNeighbors();
    int i =0, j=0;
    bool foundStart = false;
    while(i<ROW && !foundStart)
    {
        j=0;
        while(j<COL && !foundStart)
        {
            if(m_grid[i][j]->getType()==HexType::START)
            {
                m_bot =new Robot(m_grid[i][j],Direction::N);
                foundStart=true;
            }
            j++;
        }
        i++;
    }

}
//FONCTION DE TEST A RETIRER
void Grid::initEditorTestGrid()
{ for(int i =0 ; i<ROW;i++)
    {
        for (int j =0; j<COL;j++)
        {
            m_grid[i][j]=new Cell(i,j);
            m_grid[i][j]->repositionStartPos({25.,25.});
            m_grid[i][j]->initCell(10,i,j);
            if(i==2&&j==2)
            {
                m_grid[i][j]->initCell(23,i,j);
            }
            if(i==3&&j==2)
            {
                m_grid[i][j]->initCell(12,i,j);
            }
            if(i==3&&j==6)
            {
                m_grid[i][j]->initCell(30,i,j);
            }
            if(i==4&&j==6)
            {
                m_grid[i][j]->initCell(20,i,j);
            }

        }
    }

    initCellNeighbors();
    int i =0, j=0;
    bool foundStart = false;
    while(i<ROW && !foundStart)
    {
        j=0;
        while(j<COL && !foundStart)
        {
            if(m_grid[i][j]->getType()==HexType::START)
            {
                m_bot =new Robot(m_grid[i][j],Direction::N);
                foundStart=true;
            }
            j++;
        }
        i++;
    }

}
/****************** Nom de la fonction **********************
* initCellNeighbors*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet d'initialiser les voisins d'une case
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Grid::initCellNeighbors()
{

    for(int i =0 ; i<ROW;i++)
    {
        for (int j =0; j<COL;j++)
        {

            if(i-1>=0)
            {
                m_grid[i][j]->addNeighbor("N",m_grid[i-1][j]);
            }
            if(i+1<ROW)
            {
                m_grid[i][j]->addNeighbor("S",m_grid[i+1][j]);
            }
            if(j%2==1)
            {
                if(j-1>=0)
                {
                    m_grid[i][j]->addNeighbor("NW",m_grid[i][j-1]);
                }
                if(j-1>=0 &&i+1<ROW)
                {
                    m_grid[i][j]->addNeighbor("SW",m_grid[i+1][j-1]);
                }

                if(j+1 <COL)
                {
                    m_grid[i][j]->addNeighbor("NE",m_grid[i][j+1]);
                }
                if(j+1<COL && i+1<ROW)
                {

                    m_grid[i][j]->addNeighbor("SE",m_grid[i+1][j+1]);
                }
            }
            else if (j%2==0)
            {
                if(j-1>=0)
                {
                    m_grid[i][j]->addNeighbor("SW",m_grid[i][j-1]);
                }
                if(j-1>=0 && i-1>=0)
                {

                    m_grid[i][j]->addNeighbor("NW",m_grid[i-1][j-1]);
                }
                if(j+1<COL &&i-1>=0)
                {
                    m_grid[i][j]->addNeighbor("NE",m_grid[i-1][j+1]);
                }
                if(j+1 <COL)
                {
                    m_grid[i][j]->addNeighbor("SE",m_grid[i][j+1]);
                }

            }
        }
    }
}
Cell *Grid::getCell(int i, int j)
{
    return m_grid[i][j];
}
