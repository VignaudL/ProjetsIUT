#ifndef BUTTON_H
#define BUTTON_H
#include <SFML/Graphics.hpp>
#include <math.h>

const std::string QUIT ="../Ressources/quit.png",
QUITR="../Ressources/quitround.png",
PLAY="../Ressources/Play.png",
GAMEBUTTONS= "../Ressources/GameButtons.png",
RESETBUTTON="../Ressources/reset.png",
RESETGAMEBUTTON="../Ressources/resetLvl.png",
LVLGAMEBUTTONS="../Ressources/lvlButtons.png",
HEXBUTTON="../Ressources/tiles.png";

enum class ButtonType{
    Quit,Clear,
Play,MenuEdit,MenuLevel,MenuCustomLevel,
JeuReset,JeuStop,JeuAvancer,JeuPivotG,JeuPivotD,JeuSauter,JeuAllumer, JeuP1, JeuP2,
EditTest,EditSave,EditDelete,EditAdd,EditPlaceStart,EditPlaceTreasure,null
                    } ;

using Coord = sf::Vector2f;
class Button
{
public:
    //Constructeur de Bouton Rond
    Button(Coord pos,ButtonType type,  float radius);
    //Constructeur de Bouton Carre
    Button(Coord pos, ButtonType type,  float width, float height);
    Button(Button *b);
    void draw_Button(sf::RenderWindow &window,Coord mouse);
       ButtonType getType();
          bool isOnButton(Coord pos);
          void setLvlNum(int n);
          int getLvlNum();
          void setButtonPos(Coord pos);
          Coord getButtonPos();
          void switchGameButton();


private:
    bool m_isSquare;
    sf::CircleShape m_circle;
    sf::RectangleShape m_rect;
    void spriteDraw(sf::RenderWindow &window);


    Coord m_pos;
    ButtonType m_type;
    Coord m_center;
    int m_lvlnum =0;
sf::Texture m_texture;
sf::Sprite m_sprite;


    void setButtonAppearance(sf::Shape &s,Coord mouse);


};

#endif // BUTTON_H
