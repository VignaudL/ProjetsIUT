#include "Editor.h"

Editor::Editor(Appli * a):m_app(a)
{
    m_BGText.loadFromFile(BACK);
    m_backGround.setTexture(m_BGText);

    m_hexgrid=new Grid();
    m_hexgrid->initEditorTestGrid();
    m_editorHexGrid=new EditorGrid(sf::FloatRect(717.,2.,563.,423.),m_hexgrid);

    m_buttonseditor.push_back(new Button({0,630},ButtonType::Quit,45));
    m_buttonseditor.push_back(new Button({ADDX,HEXBUTY},ButtonType::EditAdd,HEXBUTW,ADDH));
    m_buttonseditor.push_back(new Button({DELETEX,HEXBUTY},ButtonType::EditDelete,HEXBUTW,DELETEH));
    m_buttonseditor.push_back(new Button({STARTX,HEXBUTY},ButtonType::EditPlaceStart,HEXBUTW,STARTH));
    m_buttonseditor.push_back(new Button({TREASUREX,HEXBUTY},ButtonType::EditPlaceTreasure,HEXBUTW,ADDH));
}
Editor::~Editor()
{
    for(auto b:m_buttonseditor)
    {
        delete b;
    }
    delete m_hexgrid;
}
void Editor::loop()
{
    m_app->m_window.clear();
    drawEditor(m_app->m_window);
    m_app->m_window.display();

}
void Editor::mouse_pressed()
{
    for(Button * b:m_buttonseditor)
    {
        if(b->isOnButton(m_app->m_mouse))
        {
            switch(b->getType())
            {
            case ButtonType::Quit:
                m_app->changeState(State::menu);
                break;
            case ButtonType::EditAdd:

                m_movingTool=true;
                m_movedTool=new Button(b);
                m_editorHexGrid->setTool(ButtonType::EditAdd);
                break;
            case ButtonType::EditDelete:
                m_movingTool=true;
                m_movedTool=new Button(b);
                m_editorHexGrid->setTool(ButtonType::EditDelete);
                break;
            case ButtonType::EditPlaceStart:
                m_movingTool=true;
                m_movedTool=new Button(b);
                m_editorHexGrid->setTool(ButtonType::EditPlaceStart);
                break;
            case ButtonType::EditPlaceTreasure:
                m_movingTool=true;
                m_movedTool=new Button(b);
                m_editorHexGrid->setTool(ButtonType::EditPlaceTreasure);
                break;
            default:
                break;

            }
        }
    }
}
void Editor::mouse_released()
{
    if(m_movingTool)
    {
        m_movingTool=false;
        m_editorHexGrid->cellPressed(m_app->m_mouse);
        delete m_movedTool;
        m_movedTool=nullptr;

    }
}
void Editor::mouse_moved()
{
    if (m_movingTool){

        m_movedTool->setButtonPos(m_app->m_mouse);
    }
}
void Editor::drawEditor(sf::RenderWindow &window)
{
    window.draw(m_backGround);
    for(Button * b:m_buttonseditor)
    {
        b->draw_Button(window,m_app->m_mouse);
    }

    m_hexgrid->drawGrid(window);
    m_editorHexGrid->drawEditgrid(window,m_app->m_mouse);
    if(m_movingTool)
    {
        m_movedTool->draw_Button(window,m_app->m_mouse);
    }
}


