#include "Appli.h"

/****************** Nom de la fonction **********************
*Appli*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*Constructeur de l'appli*
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Appli::Appli():m_window({W,H},"LightBot")
{

}
/****************** Nom de la fonction **********************
* ~Appli*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Destructeur d'appli *
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Appli::~Appli()
{

    delete m_menu;
    delete m_game;
    delete m_editor;

}
/****************** Nom de la fonction **********************
* Stop*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet d'arrêter l'application*
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Appli::stop()
{
    m_running=false;
}

/****************** Nom de la fonction **********************
* run*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de lancer et faire tourner l'application*
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Appli::run()
{
    m_window.setFramerateLimit(40);
    m_running=true;
    m_state=State::menu;
    m_menu = new Menu(this);
    m_game = new Game(this);
    m_editor = new Editor(this);




    while(m_running)
    {

        process_event();
        switch(m_state)
        {
        case State::menu:
            m_menu->loop();

            break;

        case State::game:
            m_game->loop();
            break;
        case State::editor:
            m_editor->loop();

            break;

        default:
            break;
        }

    }
}
/****************** Nom de la fonction **********************
* launchLvl*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de lancer le niveau correspondant  au numéro passé en paramètre *
*********************** Entrées *****************************
*un entier*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Appli::launchLvl(int n)
{
m_game->startLvl(n);
}
/****************** Nom de la fonction **********************
* process_event*
******************** Auteur , Dates *************************
* Montferme Robin,Loic Vignaud*
********************* Description ***************************
*  Permet de gérer les évènements lié à la souris *
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Appli::process_event()
{
    sf::Event event;
    if(!m_window.isOpen())
    {
        stop();
        return;
    }

    while(m_window.pollEvent(event))
    {
        switch(event.type)
        {
        case sf::Event::Closed:
            stop();
            break;
        case sf::Event::MouseButtonPressed:
            switch(m_state)
            {
            case State::menu:
                m_menu->mouse_pressed();
                break;
            case State::game:
                m_game->mouse_pressed();
                break;
            case State::editor:
                m_editor->mouse_pressed();
                break;
            default:
                break;
            }

            break;
        case sf::Event::MouseButtonReleased:

            switch(m_state)
            {
            case State::menu:

                break;
            case State::game:
                m_game->mouse_released();
            break;
            case State::editor:
                m_editor->mouse_released();
                break;
            default:
                break;
            }

            break;
        case sf::Event::MouseMoved:
            setMousePos(event.mouseMove.x,event.mouseMove.y);

            switch(m_state)
            {
            case State::game:

                m_game->mouse_moved();
                break;
            case State::editor:
                m_editor->mouse_moved();
                break;

            default:
                break;
            }


        default:
            break;
        }
    }

}
/****************** Nom de la fonction **********************
* changeState*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de changer l'état de l'application *
*********************** Entrées *****************************
*Un état*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Appli::changeState(State s)

{
    m_state=s;
}
/****************** Nom de la fonction **********************
* setMousePos*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de récuper sous forme de position les coordonnés de la souris par rappor à la fenêtre*
*********************** Entrées *****************************
*2 float*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Appli::setMousePos(float x, float y)
{
    Coord pos = m_window.mapPixelToCoords( {x, y});
    m_mouse = { pos.x, pos.y };
}


