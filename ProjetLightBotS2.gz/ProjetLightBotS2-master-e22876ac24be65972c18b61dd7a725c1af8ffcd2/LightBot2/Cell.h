#ifndef CELL_H
#define CELL_H
#include "Robot.h"
#include <SFML/Graphics.hpp>
class Robot;
const std::string  HEXES = "../Ressources/tiles.png";
const float CELLX=100.,CELLY=100.,CELLYD=CELLY+36.,OFFSETY=72.,OFFSETDX=92.;
const float SPRITEW=128.,SPRITEH=76;

using Coord = sf::Vector2f;
enum class HexHeight {HOLE, DEFAULT, FIRSTFLOOR, SECONDFLOOR};

enum class  HexType{START, TREASUREOFF,TREASUREON, DEFAULT};

class Cell
{
public:
    //Cell(HexHeight h, HexType t, float rad, Coord pos, bool gameGrid=false);
    Cell(int i, int j);

    //HexHeight ChangeHeight(HexHeight  height);
    //HexType ChangeType(HexType type);

    void initCell(int n, int i, int j );
    void setHexAppearance();

    void draw_Hex(sf::RenderWindow &window);

    void addNeighbor(std::string dir, Cell*c);
    Coord getCenter();
    bool isCellValid(Cell*c, bool jump);
    Cell * getNeighbor(std::string dir);
    HexHeight getHeight();
    HexType getType();
void setType(HexType t);
void setHeight(HexHeight h);
void repositionStartPos(Coord pos);


private:


    HexHeight m_altitude;
    HexType m_type;
    Robot* m_robot;
    std::map<std::string,Cell*>m_neighbors;

    Coord m_position;
    int m_i;
    int m_j;
Coord m_startPos;
sf::Texture m_cellTexture;
    sf::Sprite m_cellSprite;
 Coord m_cellCenter;


    HexType i2HexType(int i);
    HexHeight i2HexHeight(int i);
    Coord int2Pos(int i, int j);


};

#endif // CELL_H
