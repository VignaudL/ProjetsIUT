#include "Robot.h"
/****************** Nom de la fonction **********************
Robot
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
Constructeur de Robot
*********************** Entrées *****************************
Pointeur de Cellule et une direction
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Robot::Robot(Cell * pos,Direction dir):m_pos(pos),m_direction(dir)
{
    m_botTexture.loadFromFile(BOTTEXT);
    m_botSprite.setTexture(m_botTexture);
    m_temp.setFillColor(sf::Color::White);
    m_temp.setRadius(5);
    m_temp.setPosition(pos->getCenter().x-2.5,pos->getCenter().y-2.5);
    m_temp.setOrigin(m_temp.getRadius(),m_temp.getRadius());

}
/****************** Nom de la fonction **********************
rotation
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de réorienter la direction du robot
*********************** Entrées *****************************
Sens de rotation
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Robot::rotation(Sens s)
{
    switch(s)
    {
    case Sens::HORAIRE:
        switch (m_direction) {
        case Direction::N:
            m_direction=Direction::NE;
            break;
        case Direction::S:
            m_direction=Direction::SW;
            break;
        case Direction::NW:
            m_direction=Direction::N;
            break;
        case Direction::SW:
            m_direction=Direction::NW;
            break;
        case Direction::NE:
            m_direction=Direction::SE;
            break;
        case Direction::SE:
            m_direction=Direction::S;
            break;

        }

        break;
    case Sens::ANTIHORAIRE:
        switch (m_direction) {
        case Direction::N:
            m_direction=Direction::NW;
            break;
        case Direction::S:
            m_direction=Direction::SE;
            break;
        case Direction::NW:
            m_direction=Direction::SW;
            break;
        case Direction::SW:
            m_direction=Direction::S;
            break;
        case Direction::NE:
            m_direction=Direction::N;
            break;
        case Direction::SE:
            m_direction=Direction::NE;
            break;
        }


        break;
    }

}
/****************** Nom de la fonction **********************
dir2string
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
convertit une direction en chaîne de caractère
*********************** Entrées *****************************
une direction
*********************** Sorties *****************************
une chaîne de caractère
************************************************************/
std::string Robot::dir2String(Direction d)
{
    switch(d)
    {
    case Direction::N:
        return "N";
        break;
    case Direction::S:
        return "S";
        break;
    case Direction::NW:
        return "NW";
        break;
    case Direction::SW:
        return "SW";
        break;
    case Direction::NE:
        return "NE";
        break;
    case Direction::SE:
        return "SE";
        break;
    }
}
/****************** Nom de la fonction **********************
updatePos
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de faire la mise à jour de la position actuelle du robot
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Robot::updatePos()
{
    m_temp.setPosition(m_pos->getCenter().x-2.5,m_pos->getCenter().y-2.5);

}
/****************** Nom de la fonction **********************
moveForward
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  fait avancer le robot d'une case dans la directionà laquelle il fait face
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Robot::moveForward()
{
    if(m_pos->getNeighbor(dir2String(m_direction))->isCellValid(m_pos,false) && m_pos->getNeighbor(dir2String(m_direction))!=m_pos)
    {
        m_pos=m_pos->getNeighbor(dir2String(m_direction));
        updatePos();
    }
}
/****************** Nom de la fonction **********************
jumpForwars
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
fait sauter en avant le robot dans la direction à laquelle il fait face. Si la case est au même niveau que celle sur laquelle est le robot il saute sur place
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Robot::jumpForward()
{
    if(m_pos->getNeighbor(dir2String(m_direction))->getHeight()!=m_pos->getHeight())
    {
    if(m_pos->getNeighbor(dir2String(m_direction))->isCellValid(m_pos,true) && m_pos->getNeighbor(dir2String(m_direction))!=m_pos)
    {
        m_pos=m_pos->getNeighbor(dir2String(m_direction));
        updatePos();
    }
    }
}
/****************** Nom de la fonction **********************
draw_robot
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*affiche le robot
*********************** Entrées *****************************
une fenêtre de rendu
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Robot::drawRobot(sf::RenderWindow &window)
{ updatePos();
    window.draw(m_temp);

}
/****************** Nom de la fonction **********************
setRobotAppearance
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
Définit l'apparence du Robot
*********************** Entrées *****************************
Pas d'Entrée
*********************** Sorties *****************************
*Pas de Sortie*
***********************************************************/
void Robot::setRobotAppearance()
{
    switch(m_direction)
    {
    case Direction::N:


        break;
    case Direction::NE:

        break;
    case Direction::SE:

        break;
    case Direction::NW:

        break;
    case Direction::SW:

        break;
    case Direction::S:

        break;
    }
}
/****************** Nom de la fonction **********************
lightCell
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
allume une case Trésor si le robot se trouve sur le case trésor
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Robot::lightCell()
{
    if(m_pos->getType()==HexType::TREASUREOFF)
    {
        m_pos->setType(HexType::TREASUREON);
    }
    else if(m_pos->getType()==HexType::TREASUREON)
    {
        m_pos->setType(HexType::TREASUREOFF);
    }
}
