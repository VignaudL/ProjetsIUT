#include "Manager.h"

Manager::Manager()
{

}








