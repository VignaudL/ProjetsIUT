#ifndef MANAGER_H
#define MANAGER_H
#include <array>
#include <deque>
#include "Grid.h"





//Constantes pour la phase GAME
const float
GCELLRAD=60,
GCELLX=200.,
GCELLY=100.,
GCELLW=64,
GCELLH=39,
GBUTTONH = 75.,
GBUTTONW = 75.,
GMAINX = 850.,
GMAINY = 85.,
GMAINH = 155.,
GMAINW = 375.;
const float
GPLAYX=15,
GPLAYY=569,
GPLAYW=142,
GPLAYH=87,

GCLEARX=848,
GCLEARY=626,
GCLEARW=80,
GCLEARH=87;




//Constantes pour la phase editor
const float ECELLX=60,
ECELLY=80,
ECELLRAD=50,
ECELLW=(ECELLRAD*4),
ECELLH=(ECELLRAD*sqrt(3.)),
EDITINGX=650,
EDITINGY=ECELLY*2;
//Constantes pour charger les sprites




class Manager
{
public:
    Manager();
 virtual~Manager(){};

protected:
    virtual void loop()=0;
    virtual void mouse_pressed()=0;
    virtual void mouse_released()=0;
    virtual void mouse_moved()=0;




    Grid *m_hexgrid;
    sf::Sprite m_backGround;
    sf::Texture m_BGText;


};

#endif // MANAGER_H
