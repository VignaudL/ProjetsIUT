#ifndef ROBOT_H
#define ROBOT_H
#include "Cell.h"
#include <SFML/Graphics.hpp>
class Cell;
const std::string BOTTEXT="../Ressources/Robot.png";

enum class Direction{N,S,NW,SW,NE,SE};
enum class Sens{HORAIRE,ANTIHORAIRE};

class Robot
{
public:
    Robot(Cell* pos,Direction dir);
    void rotation(Sens s);
    void moveForward();
    void jumpForward();
    void lightCell();
    void drawRobot(sf::RenderWindow &window);
private:
Cell * m_pos;
Direction m_direction;
sf::CircleShape m_temp;
std::string dir2String(Direction d);
void updatePos();
void setRobotAppearance();
sf::Texture m_botTexture;
sf::Sprite m_botSprite;


};

#endif // ROBOT_H
