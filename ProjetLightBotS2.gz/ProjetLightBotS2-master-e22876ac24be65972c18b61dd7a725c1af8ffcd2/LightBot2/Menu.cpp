#include "Menu.h"
/****************** Nom de la fonction **********************
* Menu*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*Constructeur de Menu*
*********************** Entrées *****************************
*Pointeur d'Appli
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Menu::Menu(Appli *a):m_app(a)
{
    m_bgTex.loadFromFile(BACK);
    m_background.setTexture(m_bgTex);
    m_mainButtons.push_back(new Button({PLAYX,PLAYY},ButtonType::Play,PLAYW,PLAYH));
    m_mainButtons.push_back(new Button({QUITX,QUITY},ButtonType::Quit,QUITW,QUITH));
    m_mainButtons.push_back(new Button({MENUEDITX,MENUEDITY},ButtonType::MenuEdit,MENUEDITW,MENUEDITH));
    m_lvlSelectButtons.push_back(new Button({20,600},ButtonType::Quit,45));



    int n =0;
    for(int i = 0; i<2;i++)
    {
        for(int j = 0;j<5;j++)
        {
            m_lvlSelectButtons.push_back(new Button({LEVELXY+j*(LEVELWH+LEVELSPACING),LEVELXY+i*(LEVELWH+LEVELSPACING-40)},ButtonType::MenuLevel,100.,100.));

        }
    }
    for(Button* b:m_lvlSelectButtons)
    {
        if(b->getType()==ButtonType::MenuLevel)
        {
            b->setLvlNum(n);
            n++;
        }
    }

}
/****************** Nom de la fonction **********************
*loop*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
* boucle de menu
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Menu::loop()
{
    m_app->m_window.clear();
    m_app->m_window.draw(m_background);
    if(m_main)
    {
        for(Button * b :m_mainButtons)
        {
            b->draw_Button(m_app->m_window,m_app->m_mouse);
        }
    }
    else if(!m_main)
    {
        for(Button * b :m_lvlSelectButtons)
        {
            b->draw_Button(m_app->m_window,m_app->m_mouse);
        }
    }
    m_app->m_window.display();
}
/****************** Nom de la fonction **********************
*mouse_pressed*
******************** Auteur , Dates *************************
* Montferme Robin,Loic Vignaud*
********************* Description ***************************
*gère les événement lié au cliqu    m_hexgrid->initTestGrid();e maintenu de la souris
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Menu::mouse_pressed()
{
    if(m_main)
    {
        for(Button * b:m_mainButtons)
        {
            if(b->isOnButton(m_app->m_mouse))
            {
                menuAction(b);
            }
        }
    }
    else if(!m_main)
    {
        for(Button * b:m_lvlSelectButtons)
        {
            if(b->isOnButton(m_app->m_mouse))
            {
                lvlSelectAction(b);
            }
        }
    }
}
/****************** Nom de la fonction **********************
* menuAction*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*Gestion des évènements en fonction du bouton sur lequel on a appuyé
*********************** Entrées *****************************
Un pointeur de bouton
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Menu::menuAction(Button *b)
{
    switch(b->getType())
    {
    case ButtonType::Play:
        m_main=false;
        break;
    case ButtonType::Quit:
        m_app->stop();
        break;
    case ButtonType::MenuEdit:
        m_app->changeState(State::editor);
        break;
    default:
        break;
    }
}
/****************** Nom de la fonction **********************
*lvlSelectAction
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de lancer le niveau correspondant au bouton et lancer la boucle de jeu
*********************** Entrées *****************************
Pointeur de boutln
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Menu::lvlSelectAction(Button *b)
{
    switch(b->getType())
    {
    case ButtonType::Quit:
        changeMenuState();
        break;
    case ButtonType::MenuLevel:
        m_app->changeState(State::game);
        //m_app->launchLvl(b->getLvlNum());


        break;
    default:
        break;
    }
}
/****************** Nom de la fonction **********************
changeMenuState
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*permet de changer l'état du menu
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Menu::changeMenuState()
{
    m_main=!m_main;
}
/****************** Nom de la fonction **********************
*~Menu
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
destructeur de menu
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Menu::~Menu()
{
    for(auto b:m_mainButtons)
    {
        delete b;
    }
    for(auto b:m_lvlSelectButtons)
    {
        delete b;
    }
}
