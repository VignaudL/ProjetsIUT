#include "Button.h"
/****************** Nom de la fonction **********************
* Button*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
* Constructeur pour un bouton Circulaire*
*********************** Entrées *****************************
*Une position, un type de bouton et un rayon*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Button::Button(Coord pos,ButtonType type, float radius)
    :m_pos(pos),m_type(type),m_circle(radius),m_isSquare(false)
{
    m_center={pos.x+radius,pos.y+radius};
    switch(type)
    {
    case ButtonType::Quit:
        m_texture.loadFromFile(QUITR);
        break;
    default:
        break;
    }
    m_sprite.setTexture(m_texture);
    m_sprite.setPosition(pos);
}
/****************** Nom de la fonction **********************
* Button*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
* Constructeur pour un bouton Carré*
*********************** Entrées *****************************
*Une position, un type de bouton, une largeur et  une hauteur*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Button::Button(Coord pos, ButtonType type, float width, float height)
    :m_pos(pos),m_type(type),m_rect({width,height}),m_isSquare(true)
{
    switch(type)
    {
    case ButtonType::Quit:
        m_texture.loadFromFile(QUIT);
        break;
    case ButtonType::MenuLevel:
        m_texture.loadFromFile(LVLGAMEBUTTONS);
        break;
    case ButtonType::Play :
        m_texture.loadFromFile(PLAY);
        break;
    case ButtonType::JeuReset:
        m_texture.loadFromFile(RESETGAMEBUTTON);
        break;

    case ButtonType::Clear:
        m_texture.loadFromFile(RESETBUTTON);
        break;

    case ButtonType::JeuAvancer:
        m_texture.loadFromFile(GAMEBUTTONS);
        break;

    case ButtonType::JeuPivotG:
        m_texture.loadFromFile(GAMEBUTTONS);
        break;

    case ButtonType::JeuPivotD:
        m_texture.loadFromFile(GAMEBUTTONS);
        break;

    case ButtonType::JeuSauter:
        m_texture.loadFromFile(GAMEBUTTONS);
        break;

    case ButtonType::JeuAllumer:
        m_texture.loadFromFile(GAMEBUTTONS);
        break;

    case ButtonType::JeuP1:
        m_texture.loadFromFile(GAMEBUTTONS);
        break;

    case ButtonType::JeuP2:
        m_texture.loadFromFile(GAMEBUTTONS);
        break;
    case ButtonType::EditAdd:
        m_texture.loadFromFile(HEXBUTTON);
        break;
    case ButtonType::EditDelete:
        m_texture.loadFromFile(HEXBUTTON);
        break;
    case ButtonType::EditPlaceTreasure:
        m_texture.loadFromFile(HEXBUTTON);
        break;
    case ButtonType::EditPlaceStart:
        m_texture.loadFromFile(HEXBUTTON);
        break;



    default:
        break;
    }
    m_sprite.setTexture(m_texture);
    m_sprite.setPosition(pos);

}
/****************** Nom de la fonction **********************
* Button*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
* Constructuer d'un bouton  en copiant un bouton existant*
*********************** Entrées *****************************
*Un pointeur de bouton*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
Button::Button(Button *b)
{
    m_isSquare=b->m_isSquare;
    m_circle=b->m_circle;
    m_rect=b->m_rect;
    m_pos=b->m_pos;
    m_type=b->m_type;
    m_center=b->m_center;
    m_texture=b->m_texture;
    m_sprite=b->m_sprite;

}



/****************** Nom de la fonction **********************
* Draw_Button*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de dessiner un bouton*
*********************** Entrées *****************************
*Une fenêtre de rendu et une position*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Button::draw_Button(sf::RenderWindow &window,Coord mouse)
{

    if(m_isSquare)
    {
        m_rect.setPosition(m_pos);
        setButtonAppearance(m_rect,mouse);

        window.draw(m_rect);
        //spriteDraw(window);
        window.draw(m_sprite);
    }
    else
    {
        m_circle.setPosition(m_pos);

        setButtonAppearance(m_circle,mouse);

        window.draw(m_circle);
        //spriteDraw(window);
        window.draw(m_sprite);
    }


}
/****************** Nom de la fonction **********************
* isOnButton*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de savoir si la souris est sur un bouton*
*********************** Entrées *****************************
*Une position*
*********************** Sorties *****************************
*Un booléen*
************************************************************/
bool Button::isOnButton(Coord pos)
{
    if(m_isSquare)
    {
        if(pos.x > m_rect.getPosition().x && pos.x < (m_rect.getPosition().x + m_rect.getSize().x) && pos.y > m_rect.getPosition().y && pos.y < (m_rect.getPosition().y+m_rect.getSize().y))
        {
            return true;
        }
        return false;
    }
    else if(!m_isSquare)
    {

        if(sqrt(pow((pos.x-m_center.x),2)+pow((pos.y-m_center.y),2))<=m_circle.getRadius() )
        {
            return true;
        }
        return false;
    }
}
/****************** Nom de la fonction **********************
* setButtonAppearance*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de définir l'apparence d'un bouton à partir des attributs de l'instance*
*********************** Entrées *****************************
*Une sf::shape qui sera soit un CircleShape soit un RectangleShape et une position*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Button::setButtonAppearance(sf::Shape &s, Coord mouse)
{

    switch(m_type)
    {
    case ButtonType::Play:


        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(0,0,142,87));
        if(isOnButton(mouse))
        {

            m_sprite.setTextureRect(sf::IntRect(142,5,142,82));

        }

        break;
    case ButtonType::MenuLevel:
        m_sprite.setTextureRect(sf::IntRect(0+m_lvlnum*100,0,100,100));
        if(isOnButton(mouse))
        {
            m_sprite.setTextureRect(sf::IntRect(0+m_lvlnum*100,100,100,100));
        }
        break;

    case ButtonType::JeuReset:


        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(0,0,142,87));
        if(isOnButton(mouse))
        {

            m_sprite.setTextureRect(sf::IntRect(142,5,142,82));

        }

        break;

    case ButtonType::Quit:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(0,0,90,90));

        if(isOnButton(mouse))
        {

            m_sprite.setTextureRect(sf::IntRect(90,0,90,90));
        }
        break;
    case ButtonType::MenuEdit:
        s.setFillColor(sf::Color(0,115,0));
        if(isOnButton(mouse))
        {
            s.setFillColor(sf::Color(100,255,100));
        }
        break;
    case ButtonType::Clear:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(0,0,80,88));
        if(isOnButton(mouse))
        {
            m_sprite.setTextureRect(sf::IntRect(80,0,80,82));
        }
        break;

    case ButtonType::JeuAvancer:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(0,0,75,75));
        if(isOnButton(mouse))
        {
            m_sprite.setTextureRect(sf::IntRect(0,75,75,75));
        }
        break;

    case ButtonType::JeuAllumer:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(75,0,75,75));

        if(isOnButton(mouse))
        {
            m_sprite.setTextureRect(sf::IntRect(75,75,75,75));

        }
        break;

    case ButtonType::JeuPivotG:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(150,0,75,75));
        if(isOnButton(mouse))
        {
            m_sprite.setTextureRect(sf::IntRect(150,75,75,75));

        }
        break;

    case ButtonType::JeuPivotD:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(225,0,75,75));
        if(isOnButton(mouse))
        {
            m_sprite.setTextureRect(sf::IntRect(225,75,75,75));
        }
        break;

    case ButtonType::JeuSauter:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(300,0,75,75));
        if(isOnButton(mouse))
        {
            m_sprite.setTextureRect(sf::IntRect(300,75,75,75));
        }
        break;

    case ButtonType::JeuP1:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(375,0,75,75));
        if(isOnButton(mouse))
        {
            m_sprite.setTextureRect(sf::IntRect(375,75,75,75));
        }
        break;

    case ButtonType::JeuP2:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(450,0,75,75));
        if(isOnButton(mouse))
        {
            m_sprite.setTextureRect(sf::IntRect(450,75,75,75));
        }
        break;
    case ButtonType::EditAdd:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(256,50,128,78));
        break;
    case ButtonType::EditDelete:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(0,56,128,72));
        break;
    case ButtonType::EditPlaceStart:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(512,46,128,82));
        break;
    case ButtonType::EditPlaceTreasure:
        s.setFillColor(sf::Color::Transparent);
        m_sprite.setTextureRect(sf::IntRect(896,50,128,78));
        break;
    default:
        break;
    }



}
/****************** Nom de la fonction **********************
* SpriteDraw*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet d'afficher le sprite associé à un bouton*
*********************** Entrées *****************************
*Une fenêtre de rendu*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Button::spriteDraw(sf::RenderWindow &window)
{
//    switch(m_type)
//    {
//    case ButtonType::Quit:
//        window.draw(m_sprite);
//        break;
//    case ButtonType::MenuLevel:
//        window.draw(m_sprite);
//        break;
//    case ButtonType::Play:
//        window.draw(m_sprite);
//        break;
//    case ButtonType::JeuReset:
//        window.draw(m_sprite);
//        break;
//    case ButtonType::Clear:
//        window.draw(m_sprite);
//        break;

//    case ButtonType::JeuAvancer:
//        window.draw(m_sprite);
//        break;

//    case ButtonType::JeuPivotG:
//        window.draw(m_sprite);
//        break;

//    case ButtonType::JeuPivotD:
//        window.draw(m_sprite);
//        break;

//    case ButtonType::JeuSauter:
//        window.draw(m_sprite);
//        break;

//    case ButtonType::JeuAllumer:
//        window.draw(m_sprite);
//        break;

//    case ButtonType::JeuP1:
//        window.draw(m_sprite);
//        break;

//    case ButtonType::JeuP2:
//        window.draw(m_sprite);
//        break;


//    default:
//        break;
 //   }
}
/****************** Nom de la fonction **********************
* getType*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*getter du type de bouton*
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*le type du bouton*
************************************************************/
ButtonType Button::getType()
{
    return m_type;
}
/****************** Nom de la fonction **********************
* setLvlNum*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
* setter de m_lvlNum*
*********************** Entrées *****************************
*un entier*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Button::setLvlNum(int n)
{
    m_lvlnum=n;
}
/****************** Nom de la fonction **********************
* getLvlNum*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  getter de m_lvlNum*
*********************** Entrées *****************************
*Pas d'entréer*
*********************** Sorties *****************************
*Un entier*
************************************************************/
int Button::getLvlNum()
{
    return m_lvlnum;
}
/****************** Nom de la fonction **********************
* setButtonPos*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*setter de la position d'un bouton*
*********************** Entrées *****************************
*position*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Button::setButtonPos(Coord pos)
{
    m_pos=pos;
    m_sprite.setPosition(m_pos);
}
/****************** Nom de la fonction **********************
* getButtonPos*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  getter de la position d'un bouton*
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*une position*
************************************************************/
Coord Button::getButtonPos()
{
    //return m_sprite.getPosition();
    return m_pos;
}
/****************** Nom de la fonction **********************
* switchGameButton*
******************** Auteur , Dates *************************
* Montferme Robin*
********************* Description ***************************
*  Permet de changer un bouton play en bouton de reset de niveau et vice versa dans la boucle de jeu*
*********************** Entrées *****************************
*Pas d'entrée*
*********************** Sorties *****************************
*Pas de Sortie*
************************************************************/
void Button::switchGameButton()
{
    if(m_type==ButtonType::Play)
    {
        m_type=ButtonType::JeuReset;
        m_texture.loadFromFile(RESETGAMEBUTTON);
        m_sprite.setTexture(m_texture);
    }
    else     {
        m_type=ButtonType::Play;
        m_texture.loadFromFile(PLAY);
        m_sprite.setTexture(m_texture);
    }
}

