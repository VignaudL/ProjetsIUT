#include <iostream>
#include"Appli.h"

using namespace std;

int main()
{
    Appli a;
    a.run();
    return 0;
}

