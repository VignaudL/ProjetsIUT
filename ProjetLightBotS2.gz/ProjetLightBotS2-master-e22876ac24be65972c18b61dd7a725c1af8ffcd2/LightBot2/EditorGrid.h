#ifndef EDITORGRID_H
#define EDITORGRID_H
#include <SFML/Graphics.hpp>
#include "Button.h"
#include <array>
#include "Grid.h"

const  std::string POLICE = "../Ressources/Georgia.ttf";
using Coord = sf::Vector2f;
class EditorGrid
{
public:
    EditorGrid(const sf::FloatRect &rectangle,Grid* grid);
    ~EditorGrid();
    bool posConverter(const Coord &pos, int &i, int &j)const ;
    Coord  centerGetter(const int i , const int j) const;
    bool isInZone(const int i, const int j) const;
    void drawEditgrid(sf::RenderWindow &window, Coord mouse);
    void cellPressed(Coord mouse);
    void setTool(ButtonType b);
private:
    sf::FloatRect m_zone;
    float m_rayon;
    Coord m_pos;
    Grid * m_grid;
    sf::Font m_font;
    sf::Text m_text;
    std::array<std::array<sf::CircleShape,COL>,ROW>m_editor_grid;
    bool m_toolSelected=false;
    ButtonType m_tool=ButtonType::null;



    void setCellApppearance(int i, int j,Coord mouse);



};

#endif // EDITORGRID_H
