#include "EditorGrid.h"

EditorGrid::EditorGrid(const sf::FloatRect &rectangle , Grid *grid):
    m_zone(rectangle),m_grid(grid)
{
    m_rayon=(2.0*m_zone.width)/(1.0+3.0*COL);
    float rayon = 2*m_zone.width / (1+3*COL)-5;
    for(int i =0;i<ROW;i++)
    {
        for(int j=0;j<COL;j++)
        {
            m_editor_grid[i][j].setRadius(rayon);
            m_editor_grid[i][j].setPointCount(6);
            m_editor_grid[i][j].setRotation(30);
            m_editor_grid[i][j].setOrigin(rayon,rayon);
        }
    }

    m_font.loadFromFile(POLICE);
    m_text.setFont(m_font);
    m_text.setCharacterSize(20);
    m_text.setColor(sf::Color::White);





}
bool EditorGrid::posConverter(const Coord &pos, int& i, int &j) const
{
    Coord m_pos = centerGetter(0,0);
    float x= (pos.x-m_pos.x)/(1.5*m_rayon);
    float z = (1.732*(pos.y-m_pos.y)-(pos.x-m_pos.x))/(3*m_rayon);
    float y = -(x+z);

    int rx=std::round(x);
    int ry=std::round(y);
    int rz=std::round(z);
    float xd =std::abs(rx-x);
    float yd = std::abs(ry-y);
    float zd = std::abs(rz-z);
    if(xd>yd && xd>zd)
    {
        rx=-(ry+rz);
    }
    else
    {
        rz=-(rx+ry);
    }
    i=rx;
    j=rz+(rx-(rx &1))/2;
    return isInZone(i,j);

}
Coord EditorGrid::centerGetter(const int i, const int j) const
{
    float x = m_zone.left + (1.5*m_rayon)*(i+0.5);
    float y =m_zone.top + 1.732*m_rayon*(j+0.5*(i&1))+m_rayon;
    return {x,y};
}
bool EditorGrid::isInZone(const int  i, const  int j) const
{
    return (0<= i) &&(i<COL)&& (0<=j) && (j<ROW);
}
void EditorGrid::drawEditgrid(sf::RenderWindow &window,Coord mouse)
{
    for(int i=0; i<ROW;i++)
    {
        for(int j=0;j<COL;j++)
        {
            setCellApppearance(i,j,mouse);
            window.draw(m_editor_grid[i][j]);
            window.draw(m_text);
        }

    }
}
void EditorGrid::setCellApppearance(int i, int j, Coord mouse)
{int c,l;
    m_editor_grid[i][j].setPosition(centerGetter(j,i));
    m_editor_grid[i][j].setOutlineColor(sf::Color::Black);
    m_editor_grid[i][j].setOutlineThickness(1);
    m_editor_grid[i][j].setFillColor(sf::Color::Black);


    switch(m_grid->getCell(i,j)->getType())
    {
    case HexType::DEFAULT:
        m_editor_grid[i][j].setFillColor(sf::Color(51,102,0));
        if(posConverter(mouse,c,l))
        {
            m_editor_grid[l][c].setFillColor(sf::Color(81,132,30));
        }
        break;
    case HexType::START:
        m_editor_grid[i][j].setFillColor(sf::Color(153,0,153));
        if(posConverter(mouse,c,l))
        {
            m_editor_grid[l][c].setFillColor(sf::Color(183,30,183));
        }
        break;
    case HexType::TREASUREOFF:
        m_editor_grid[i][j].setFillColor(sf::Color(51,51,255));
        if(posConverter(mouse,c,l))
        {
            m_editor_grid[l][c].setFillColor(sf::Color(81,81,255));
        }
        break;
    case HexType::TREASUREON:
        m_editor_grid[i][j].setFillColor(sf::Color(255,255,51));
        if(posConverter(mouse,c,l))
        {
            m_editor_grid[l][c].setFillColor(sf::Color(255,255,81));
        }
        break;
    }
    switch(m_grid->getCell(i,j)->getHeight())
    {
    case HexHeight::FIRSTFLOOR:
        m_text.setString("1");
        m_text.setPosition(centerGetter(j,i));

        break;
    case HexHeight::SECONDFLOOR:
        m_text.setString("2");
        m_text.setPosition(centerGetter(j,i));
        break;
    case HexHeight::HOLE:
        m_editor_grid[i][j].setFillColor(sf::Color::Transparent);
        break;
    default:
        break;

    }
}
void EditorGrid::cellPressed(Coord mouse)
{int c,l;
    if(posConverter(mouse,c,l)&&m_toolSelected )
    {
        switch(m_tool)
        {
        case ButtonType::EditAdd:
            if(m_grid->getCell(l,c)->getHeight()==HexHeight::DEFAULT&&m_grid->getCell(l,c)->getType()!=HexType::START)
            {
                m_grid->getCell(l,c)->setHeight(HexHeight::FIRSTFLOOR);
            }
            else if(m_grid->getCell(l,c)->getHeight()==HexHeight::FIRSTFLOOR&&m_grid->getCell(l,c)->getType()!=HexType::START)
            {
                m_grid->getCell(l,c)->setHeight(HexHeight::SECONDFLOOR);
            }

            else  if(m_grid->getCell(l,c)->getType()!=HexType::START)
            {
                m_grid->getCell(l,c)->setType(HexType::DEFAULT);
                m_grid->getCell(l,c)->setHeight(HexHeight::DEFAULT);
            }
            break;
        case ButtonType::EditDelete:
            if(m_grid->getCell(l,c)->getHeight()==HexHeight::FIRSTFLOOR&&m_grid->getCell(l,c)->getType()!=HexType::START)
            {
                m_grid->getCell(l,c)->setHeight(HexHeight::DEFAULT);
            }
            else if(m_grid->getCell(l,c)->getHeight()==HexHeight::SECONDFLOOR&&m_grid->getCell(l,c)->getType()!=HexType::START)
            {
                m_grid->getCell(l,c)->setHeight(HexHeight::FIRSTFLOOR);
            }
          else  if(m_grid->getCell(l,c)->getType()!=HexType::START)
            {
                m_grid->getCell(l,c)->setType(HexType::DEFAULT);
                m_grid->getCell(l,c)->setHeight(HexHeight::HOLE);
            }
            break;
        case ButtonType::EditPlaceStart:
           { int i=0,j=0;
            bool isFound=false;
            while(i<ROW &&!isFound )
            {
                j=0;
                while(j<COL && !isFound)
                {if(m_grid->getCell(i,j)->getType()==HexType::START)
                    {
                        isFound=true;
                        m_grid->getCell(i,j)->setType(HexType::DEFAULT);
                        m_grid->getCell(i,j)->setHeight(HexHeight::DEFAULT);
                    }
                    j++;
                }
                i++;
            }

           m_grid->getCell(l,c)->setType(HexType::START);
            m_grid->getCell(l,c)->setHeight(HexHeight::DEFAULT);
        }
            break;
        case ButtonType::EditPlaceTreasure:
            m_grid->getCell(l,c)->setType(HexType::TREASUREOFF);
            break;
        default:
            break;
        }
    }
    else
    {
        m_tool=ButtonType::null;
        m_toolSelected=false;
    }
}
void EditorGrid::setTool(ButtonType b)
{
    m_tool =b;
    m_toolSelected=true;
}

