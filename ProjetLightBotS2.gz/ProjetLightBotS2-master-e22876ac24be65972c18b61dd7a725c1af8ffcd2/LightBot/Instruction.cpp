#include "Instruction.h"

Instruction::Instruction()
{

}

