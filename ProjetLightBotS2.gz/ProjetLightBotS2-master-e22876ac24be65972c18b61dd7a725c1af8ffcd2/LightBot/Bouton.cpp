#include "Bouton.h"
#include<math.h>

Bouton::Bouton(Coord pos, TypeBouton type, float radius)
    :m_pos(pos),m_type(type),m_BoutonRond(radius),m_estCarre(false)

{

}
Bouton::Bouton(Coord pos, TypeBouton type, float width, float height)
    :m_pos(pos),m_type(type),m_BoutonCarre({width,height})
{}

void Bouton::draw_button(sf::RenderWindow &window)
{
    if(m_estCarre)
    {
        m_BoutonCarre.setPosition(m_pos);
//        m_BoutonCarre.setFillColor(sf::Color::Blue);
        setButtonAppearance(m_BoutonCarre);
        window.draw(m_BoutonCarre);
    }
    else
    {
        m_BoutonRond.setPosition(m_pos);
//        m_BoutonRond.setFillColor(sf::Color::Red);
        setButtonAppearance(m_BoutonRond);
        window.draw(m_BoutonRond);
    }

}
void Bouton::setButtonAppearance(sf::Shape &s)
{
    switch(m_type)
    {
    case TypeBouton::MenuPlay:
        s.setFillColor(sf::Color::Blue);
        break;
    case TypeBouton::Quit:
        s.setFillColor(sf::Color::Red);
        break;
    case TypeBouton::MenuEdit:
        s.setFillColor(sf::Color::Green);
        break;
    }
}
bool Bouton::IsOnButton(Coord pos)
{
    if(m_estCarre)
    {

        if(pos.x>m_pos.x && pos.x<m_pos.x+m_BoutonCarre.getSize().x && pos.y > m_pos.y && pos.y<m_pos.y+m_BoutonCarre.getSize().y)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else if(!m_estCarre)
    {
        if(sqrt(pow(pos.x-(m_BoutonRond.getScale().x+m_BoutonRond.getRadius()),2)+pow(pos.y-(m_BoutonRond.getScale().y+m_BoutonRond.getRadius()),2)))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
