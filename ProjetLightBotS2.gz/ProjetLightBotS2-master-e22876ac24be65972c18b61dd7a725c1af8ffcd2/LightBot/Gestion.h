#ifndef GESTION_H
#define GESTION_H
#include "Case.h"
#include <array>
#include <string>
#include <vector>
#include"Bouton.h"

const int ROW = 5;
const int LINE = 7;
using Coord = sf::Vector2f;
class Gestion
{
public:
    Gestion();
    void load_lvl();
    virtual void mouse_pressed(){}
    virtual void mouse_released(){}
    virtual void mouse_moved(){}
protected:
    Case * m_case;
    std::array<std::array<int,ROW>,LINE>m_hexgrid;
    std::string m_currentLvl;
    int m_currentMaxMove;
    sf::RenderWindow m_window;
    Coord m_mouse;


    virtual void loop() {}

    void draw_grid(sf::RenderWindow &window){}




};

#endif // GESTION_H
