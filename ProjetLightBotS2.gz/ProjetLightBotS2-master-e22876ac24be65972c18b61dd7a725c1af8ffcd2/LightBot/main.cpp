#include "Appli.h"

int main()
{
    Appli app;

    app.run();

    return 0;
}

