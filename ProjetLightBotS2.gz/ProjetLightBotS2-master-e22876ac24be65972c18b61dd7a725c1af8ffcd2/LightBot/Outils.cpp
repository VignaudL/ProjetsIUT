#include "Outils.h"

Outils::Outils()
{

}

