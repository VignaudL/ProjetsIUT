#include "Jeu.h"

Jeu::Jeu()
{

}
void Jeu::loop()
{}
void Jeu::mouse_pressed()
{}
void Jeu::mouse_released()
{}
void Jeu::mouse_moved()
{}

