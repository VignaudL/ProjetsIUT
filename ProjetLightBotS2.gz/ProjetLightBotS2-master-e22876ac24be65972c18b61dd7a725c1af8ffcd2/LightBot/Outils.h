class Editeur;
#ifndef OUTILS_H
#define OUTILS_H
#include"Editeur.h"

//Pertinence de l'héritage de la classe??
class Outils
{
public:
    Outils();
    void SelectionOutils();

private:
    Case * m_case_modifiee;
    enum class typeOutil
    {add,supress,start,treasure,move} m_typeOutil;
    Editeur* m_editeur;




};

#endif // OUTILS_H
