
#include "Menu.h"



Menu::Menu(sf::RenderWindow * window):m_window(window)
{
    m_boutons_Menu.push_back(new Bouton({PLAYX,PLAYY},TypeBouton::MenuPlay,PLAYW,PLAYH));
    m_boutons_Menu.push_back(new Bouton({MENUQUITX,MENUQUITY},TypeBouton::Quit,MENUQUITW,MENUQUITH));
    m_boutons_Menu.push_back(new Bouton({MENUEDITX,MENUEDITY},TypeBouton::MenuEdit,MENUEDITW,MENUEDITH));
    m_boutons_Level.push_back(new Bouton({595,445},TypeBouton::Quit,10));
}
void Menu::loop()
{
    if(m_main_menu)
    {

        m_window->clear(sf::Color(106,106,106));

    }
    else if(!m_main_menu)
    {
        m_window->clear(sf::Color::Green);
    }
    draw_menu();
    m_window->display();

}
void Menu::mouse_pressed(Coord &pos)
{
    if(m_main_menu)
    {
        for(Bouton * b: m_boutons_Menu)
        {
            if(b->IsOnButton(pos))
            {}
        }
    }
}
Menu::~Menu()
{
    for(Bouton* b:m_boutons_Menu)
    {
        delete b;
    }
    for(Bouton* b:m_boutons_Level)
    {
        delete b;
    }
}
void Menu::draw_menu()
{
    if(m_main_menu)
    {
        for(Bouton* b:m_boutons_Menu)
        {

              b->draw_button(*m_window);

        }
    }
    else if(!m_main_menu)
    {
        for(Bouton* b:m_boutons_Level)
        {
b->draw_button(*m_window);
        }
    }
}
