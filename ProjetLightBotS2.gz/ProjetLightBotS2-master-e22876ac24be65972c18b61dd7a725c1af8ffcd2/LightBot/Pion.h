#ifndef PION_H
#define PION_H
#include "Case.h"



class Pion
{
public:
    Pion();
    void Avancer();
    void Pivoter(bool direction);
    void AllumerCase();
private:
     int m_orientation;
     Case * m_pos;


};

#endif // PION_H
