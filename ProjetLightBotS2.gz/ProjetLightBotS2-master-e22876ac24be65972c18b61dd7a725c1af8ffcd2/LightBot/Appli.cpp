#include "Appli.h"

Appli::Appli():m_window({WIDTH,HEIGHT},"LightBot [Menu]")
{

}

void Appli::run()
{
;
    m_window.setFramerateLimit(60);
    m_running=true;
    m_etat=Etat::menu;

    while(m_running)
    {

     switch(m_etat)
     {
     case Etat::menu:
        m_menu = new Menu (&m_window);
          process_event();
         m_menu->loop();
         break;

     }


    }

}
void Appli::process_event()
{
    if(!m_window.isOpen())
    {
        stop();
        return;
    }
    sf::Event event;
    while(m_window.pollEvent(event))
    {
        switch(event.type)
        {
        case sf::Event::Closed:
            stop();
            break;
        case sf::Event::MouseButtonPressed:
            std::cout<<"mouse X"<<std::endl
                     <<m_mouse.x<<std::endl;
            switch(m_etat)
            {
            case Etat::menu:
               m_menu->mouse_pressed(m_mouse);
            break;
            case Etat::editeur:
            break;
            case Etat::jeu:
            break;

            }

            break;
        case sf::Event::MouseButtonReleased:
            std::cout<<"mouse Y"<<std::endl
                     <<m_mouse.y<<std::endl;
            break;
        case sf::Event::MouseMoved:
            setMousePos(event.mouseMove.x,event.mouseMove.y);
            break;
//        case sf::Event::KeyPressed:
//            testKey(event.key);
//            break;


        }
    }
}
void Appli::test_loop()
{
    m_window.clear(sf::Color::Black);
    m_window.display();
}

void Appli::test_loop2()
{
    m_window.clear(sf::Color::White);
    m_window.display();
}

void Appli::stop()
{
    m_running=false;
}

void Appli::setMousePos(float x, float y)
{
    Coord pos = m_window.mapPixelToCoords( {x, y});
    m_mouse = { pos.x, pos.y };
}

//void Appli::testKey(const sf::Event::KeyEvent &event)
//{

//   switch(event.code)
//   {
//   case sf::Keyboard::Left:
//       m_etat=Etat::jeu;
//       m_window.setTitle("LightBot [Jeu]");
//       break;
//   case sf::Keyboard::Right:
//       m_etat=Etat::menu;
//       m_window.setTitle("LightBot [Menu]");
//   }
//}
