#ifndef CASE_H
#define CASE_H
#include <SFML/Graphics.hpp>

using Coord = sf::Vector2f;
class Case
{
public:
    Case();
    int ChangeHeight(int height);
    int ChangeType(int type);
    bool mouseInHex(Coord pos);

private:
    sf::CircleShape m_hex;
    Coord m_position;
    int m_height;
    int m_width;


};

#endif // CASE_H
