;
#ifndef APPLI_H
#define APPLI_H
#include <SFML/Graphics.hpp>
#include "Menu.h"
#include "Gestion.h"
#include <iostream>
#include "Bouton.h"

const unsigned int WIDTH=1280;
const unsigned int HEIGHT=720;

class Appli
{

public:
   enum class Etat {menu,jeu,editeur} m_etat;


    Appli();
    void run();
    void setMousePos(float x, float y);
        sf::RenderWindow m_window;
private:


    Menu* m_menu=nullptr;
    Gestion* m_gestionnaire;
    bool m_running=false;
    Coord m_mouse;

    void process_event();

    void stop();
    void test_loop();
    void test_loop2();
//    void testKey(const sf::Event::KeyEvent &event);

};

#endif // APPLI_H
