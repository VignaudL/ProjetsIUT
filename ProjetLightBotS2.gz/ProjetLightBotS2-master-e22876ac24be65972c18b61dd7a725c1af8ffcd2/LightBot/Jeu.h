#ifndef JEU_H
#define JEU_H
#include "Gestion.h"
#include "Pion.h"
#include <array>
#include<queue>
#include"Instruction.h"

class Jeu : public Gestion
{
public:
    Jeu();
    void draw_point();
    void draw_movedInstructions(Coord pos);
    void loop() override;
    void mouse_pressed() override;
    void mouse_released() override;
    void mouse_moved() override;
private :
    Pion * m_pion;
    std::vector<Bouton * > m_boutons;
    std::vector<std::string>m_main_liste;
    std::vector<std::string>m_p1_liste;
    std::vector<std::string>m_p2_liste;
    std::queue<Instruction*>m_liste_execution;
    bool m_lvlDone;

};

#endif // JEU_H
