#ifndef INSTRUCTION_H
#define INSTRUCTION_H
#include "Pion.h"


class Instruction
{
public:
    Instruction();
    void stop();
    void LireInstruction();
    enum class TypeInstruction {gauche,droite,avancer,allumer,sauter,P1,P2}m_type;
private:
    Pion* m_pion;
    bool m_stop;

};

#endif // INSTRUCTION_H
