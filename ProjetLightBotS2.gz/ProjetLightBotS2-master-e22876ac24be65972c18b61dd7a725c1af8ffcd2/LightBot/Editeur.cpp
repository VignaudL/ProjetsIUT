#include "Editeur.h"

Editeur::Editeur()
{

}
void Editeur::loop()
{}
void Editeur::mouse_pressed()
{}
void Editeur::mouse_released()
{}
void Editeur::mouse_moved()
{}


