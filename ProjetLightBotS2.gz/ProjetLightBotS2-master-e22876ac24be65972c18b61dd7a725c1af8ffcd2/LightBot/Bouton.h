
#ifndef BOUTON_H
#define BOUTON_H
#include <SFML/Graphics.hpp>

enum class TypeBouton{
    Quit,Clear,
MenuPlay,MenuEdit,MenuLevel,
JeuStart,JeuStop,JeuAvancer,JeuPivotG,JePivotD,JeuSauter,JeuAllumer,
EditTest,EditSave,EditDelete,EditAdd,EditPlaceStart,EditPlaceTreasure,EditDeplacer
                    } ;
using Coord = sf::Vector2f;
class Bouton
{
public:
    //Constructeur de Bouton Rond
    Bouton(Coord pos,TypeBouton type,  float radius);
    //Constructeur de Bouton Carre
    Bouton(Coord pos, TypeBouton type,  float width, float height);

    bool IsOnButton(Coord pos);
    void draw_button(sf::RenderWindow &window);
    void setButtonAppearance(sf::Shape &s);

private:
    bool m_estCarre =true;
    sf::CircleShape m_BoutonRond;
    sf::RectangleShape m_BoutonCarre;
    Coord m_pos;


TypeBouton m_type;



};

#endif // BOUTON_H
