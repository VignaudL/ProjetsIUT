class Outils;
#ifndef EDITEUR_H
#define EDITEUR_H
#include "Gestion.h"
#include "Outils.h"

class Editeur : public Gestion
{
public:
    Editeur();
    void draw_movedHex(Coord pos);
    void loop() override;
    void mouse_pressed() override ;
    void mouse_released() override ;
    void mouse_moved() override;
    void saveCustomLvl();



private:
    std::vector<Bouton *> m_boutons;
    Outils* m_outils;

};

#endif // EDITEUR_H
