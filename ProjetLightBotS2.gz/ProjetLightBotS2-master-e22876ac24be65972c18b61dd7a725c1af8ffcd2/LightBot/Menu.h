#ifndef MENU_H
#define MENU_H
#include<SFML/Graphics.hpp>
#include<vector>
#include"Bouton.h"




const float PLAYW=250,
PLAYH=62,
PLAYX=640-(PLAYW/2),
PLAYY=320-(PLAYH/2),
MENUQUITW=100,
MENUQUITH=62,
MENUQUITX=PLAYX,
MENUQUITY=PLAYY+MENUQUITH+2,
MENUEDITW=MENUQUITW,
MENUEDITH=MENUQUITH,
MENUEDITX=PLAYX+PLAYW-MENUEDITW,
MENUEDITY=MENUQUITY;


using Coord= sf::Vector2f;
class Menu
{

public:


    Menu(sf::RenderWindow * window);
    ~Menu();
     void loop();
     void mouse_pressed(Coord & pos);
     void mouse_released();

private:
    bool m_main_menu=true;
   void draw_menu();
   Coord *m_mouse;

    sf::RenderWindow*  m_window;
    std::vector<Bouton*>m_boutons_Menu;
    std::vector<Bouton*>m_boutons_Level;
};

#endif // MENU_H
