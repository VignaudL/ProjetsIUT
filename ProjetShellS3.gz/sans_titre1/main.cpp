#include <iostream>
#include <unistd.h>
#include <vector>
#include <sys/types.h>
#include <pwd.h>
#include <map>
#include <sstream>
#include <string>

using namespace std;

using Action = void (*)();
bool encore=true;

void action_help() {
    cout << "exit pour quitter" << endl;
    cout << "! pour lancer un sous-shell" << endl;
}
void action_exit() {
    encore = false;
    cout << "zzzz" << endl;
}
void action_cd(){
    struct passwd *pw = getpwuid(getuid());
    const char *homedir = pw->pw_dir;
    int ret = chdir(homedir);
    cout << "cd HOME retourne : " << ret << endl;
}

void action_sous_shell(){
    system("/bin/bash");
}
const map<string, Action> actions{
    { "exit" , action_exit },
    { "help" , action_help},
    {"!", action_sous_shell},
    {"cd", action_cd}
};

vector<string> decouper(const string &ligne)
{
    vector<string> mots;
    istringstream in (ligne);
    string m;
    while (in >> m) {
        mots.push_back(m);
    }
    return mots;
}

void cd(string directory){
    const char * directory_c = directory.c_str();
    int ret = chdir(directory_c);
    cout << "chdir a fonctionné : "<< ret << endl;
}

void write_prompt()
{
    string chaine = (getenv("PWD"));
    chaine += ":~$";
    const char * s = chaine.c_str();
    int l = chaine.size();
    write(STDOUT_FILENO,s,l);
}

void clearTampon( char tampon[], int size_tampon)
{
    for ( int i = 0 ; i < size_tampon ; i++ )
        tampon[i] = ' ';
}

int main()
{

    vector<string> mots;

    while (encore)
    {
//        write_prompt(); // not working with cd

        int size_tampon = 20;
        char tampon [size_tampon];
        read(STDIN_FILENO, tampon, size_tampon);
        mots = decouper(tampon);

        auto it = actions.find(mots[0]);

        if (it != actions.end())
        {
            int size = mots.size();
            if ((mots[0] == "cd") && (size > 2)){
                cd(mots[1]);
            }
            else if ( ( mots[0] == "!" ) && ( size >= 2 ))
            {
                string temp = "";
                for (int i = 1 ; i < size ; i++)
                {
                    temp += mots[i];
                    temp += " " ;

                }
                const char * a = temp.c_str();
                system(a);
            }
            else
                it->second();
        }
        else
        {
            cout << "Commande inconnue : taper help " << endl;
        }
        clearTampon(tampon, size_tampon);
    }
        std::cout << " ------------------------ " << std::endl;

    return 0;
}

